import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { BarChart, LineChart, PieChart } from "lucide-react"
import VoterBubbleChart from "@/components/voter-bubble-chart"
import VotingTrendsCircularPlot from "@/components/voting-trends-circular-plot"
import DemographicDonutChart from "@/components/demographic-donut-chart"
import RegionalVoterBubbles from "@/components/regional-voter-bubbles"

export default function VotersDashboard() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <BarChart className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold">VoterViz</span>
          </div>
          <nav className="hidden md:flex gap-6">
            <a href="#" className="text-sm font-medium hover:text-primary">
              Dashboard
            </a>
            <a href="#" className="text-sm font-medium hover:text-primary">
              Demographics
            </a>
            <a href="#" className="text-sm font-medium hover:text-primary">
              Trends
            </a>
            <a href="#" className="text-sm font-medium hover:text-primary">
              About
            </a>
          </nav>
          <div className="flex items-center gap-4">
            <Button variant="outline" size="sm">
              Export Data
            </Button>
            <Button size="sm">Share Insights</Button>
          </div>
        </div>
      </header>

      <main className="flex-1 container py-6">
        <div className="flex flex-col gap-6">
          <div className="flex flex-col gap-2">
            <h1 className="text-3xl font-bold tracking-tight">Voters Data Dashboard</h1>
            <p className="text-muted-foreground">
              Interactive visualization of voter demographics, turnout, and electoral trends
            </p>
          </div>

          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="flex gap-2">
              <Button variant="outline" size="sm" className="h-8 gap-1">
                <LineChart className="h-4 w-4" />
                Trends
              </Button>
              <Button variant="outline" size="sm" className="h-8 gap-1">
                <PieChart className="h-4 w-4" />
                Demographics
              </Button>
              <Button variant="outline" size="sm" className="h-8">
                2020-2024
              </Button>
            </div>
            <div className="flex gap-2">
              <Select defaultValue="national">
                <SelectTrigger className="w-[180px] h-8">
                  <SelectValue placeholder="Select region" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="national">National</SelectItem>
                  <SelectItem value="northeast">Northeast</SelectItem>
                  <SelectItem value="midwest">Midwest</SelectItem>
                  <SelectItem value="south">South</SelectItem>
                  <SelectItem value="west">West</SelectItem>
                </SelectContent>
              </Select>
              <Select defaultValue="all">
                <SelectTrigger className="w-[180px] h-8">
                  <SelectValue placeholder="Select age group" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Ages</SelectItem>
                  <SelectItem value="18-29">18-29</SelectItem>
                  <SelectItem value="30-44">30-44</SelectItem>
                  <SelectItem value="45-64">45-64</SelectItem>
                  <SelectItem value="65+">65+</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="demographics">Demographics</TabsTrigger>
              <TabsTrigger value="turnout">Voter Turnout</TabsTrigger>
              <TabsTrigger value="trends">Voting Trends</TabsTrigger>
            </TabsList>
            <TabsContent value="overview" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Voter Demographics</CardTitle>
                    <CardDescription>Distribution by age, gender, and education</CardDescription>
                  </CardHeader>
                  <CardContent className="h-[400px]">
                    <VoterBubbleChart />
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader>
                    <CardTitle>Voting Trends</CardTitle>
                    <CardDescription>Circular representation of voting patterns over time</CardDescription>
                  </CardHeader>
                  <CardContent className="h-[400px]">
                    <VotingTrendsCircularPlot />
                  </CardContent>
                </Card>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Demographic Breakdown</CardTitle>
                    <CardDescription>Voter composition by demographic factors</CardDescription>
                  </CardHeader>
                  <CardContent className="h-[400px]">
                    <DemographicDonutChart />
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader>
                    <CardTitle>Regional Distribution</CardTitle>
                    <CardDescription>Voter concentration by geographic region</CardDescription>
                  </CardHeader>
                  <CardContent className="h-[400px]">
                    <RegionalVoterBubbles />
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            <TabsContent value="demographics">
              <div className="grid grid-cols-1 gap-4 mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Detailed Demographic Analysis</CardTitle>
                    <CardDescription>Comprehensive breakdown of voter demographics</CardDescription>
                  </CardHeader>
                  <CardContent className="h-[600px]">
                    <VoterBubbleChart />
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            <TabsContent value="turnout">
              <div className="grid grid-cols-1 gap-4 mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Voter Turnout Analysis</CardTitle>
                    <CardDescription>Turnout rates by demographic groups and regions</CardDescription>
                  </CardHeader>
                  <CardContent className="h-[600px]">
                    <RegionalVoterBubbles />
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            <TabsContent value="trends">
              <div className="grid grid-cols-1 gap-4 mt-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Voting Pattern Trends</CardTitle>
                    <CardDescription>Historical voting patterns and future projections</CardDescription>
                  </CardHeader>
                  <CardContent className="h-[600px]">
                    <VotingTrendsCircularPlot />
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Key Insights</CardTitle>
                <CardDescription>Notable patterns in the data</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <span className="rounded-full bg-primary h-2 w-2 mt-2"></span>
                    <span>Voter turnout increased by 7% in the 18-29 age group</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="rounded-full bg-primary h-2 w-2 mt-2"></span>
                    <span>Urban areas showed 12% higher participation than rural regions</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="rounded-full bg-primary h-2 w-2 mt-2"></span>
                    <span>Education level correlates strongly with consistent voting patterns</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Methodology</CardTitle>
                <CardDescription>How this data was collected and analyzed</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Data was collected through exit polls, voter registrations, and census information. Statistical
                  analysis was performed using weighted sampling to ensure representation across demographic groups.
                  Margin of error is ±2.5% with 95% confidence.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>About the Data</CardTitle>
                <CardDescription>Sources and limitations</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  This visualization uses data from the National Election Studies, Census Bureau, and state election
                  boards. Updated quarterly with the most recent information available. Some regional data may be
                  limited in smaller voting districts.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <footer className="border-t py-6">
        <div className="container flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <BarChart className="h-5 w-5 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">VoterViz Data Platform</span>
          </div>
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} VoterViz. Data visualizations for electoral insights.
          </p>
          <div className="flex gap-4">
            <a href="#" className="text-sm text-muted-foreground hover:text-foreground">
              Privacy
            </a>
            <a href="#" className="text-sm text-muted-foreground hover:text-foreground">
              Terms
            </a>
            <a href="#" className="text-sm text-muted-foreground hover:text-foreground">
              Contact
            </a>
          </div>
        </div>
      </footer>
    </div>
  )
}

