module.exports = {
  onMount: function () {},
};
