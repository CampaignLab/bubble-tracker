module.exports = {
  onInput: function (input) {
    this.name = input.name;
  },

  onMount: function () {},
};
