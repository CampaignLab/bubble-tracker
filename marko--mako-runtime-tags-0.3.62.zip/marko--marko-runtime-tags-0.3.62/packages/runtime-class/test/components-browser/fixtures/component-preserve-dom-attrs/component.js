module.exports = {
  onInput: function () {
    this.state = {
      name: "Joe",
    };
  },
};
