module.exports = {
  onMount: function () {
    this.mouseMoved = false;
  },

  handleMouseMove: function () {
    this.mouseMoved = true;
  },
};
