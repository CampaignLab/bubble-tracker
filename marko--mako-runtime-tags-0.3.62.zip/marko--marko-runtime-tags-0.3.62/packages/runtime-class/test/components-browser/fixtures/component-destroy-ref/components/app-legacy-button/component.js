module.exports = {
  onMount: function () {
    this.name = "app-legacy-button";
  },
};
