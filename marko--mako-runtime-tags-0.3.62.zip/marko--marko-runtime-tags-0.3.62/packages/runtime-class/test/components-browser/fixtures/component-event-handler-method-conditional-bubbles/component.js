module.exports = {
  onMount: function () {
    this.clicked = false;
  },

  handleButtonClick: function () {
    this.clicked = true;
  },
};
