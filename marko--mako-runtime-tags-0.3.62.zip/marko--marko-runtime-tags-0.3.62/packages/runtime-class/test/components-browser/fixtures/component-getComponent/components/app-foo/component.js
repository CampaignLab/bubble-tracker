module.exports = {
  onMount: function () {
    this.name = "app-foo";
  },
};
