"use strict";

if (typeof document === "undefined") {
  exports.require = require;
}
