var Template = require("../../../vdom").Template;
var patch = require("./").patch;
patch(Template);
