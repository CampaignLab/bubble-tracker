module.exports = require("@internal/components-define-widget-legacy");
