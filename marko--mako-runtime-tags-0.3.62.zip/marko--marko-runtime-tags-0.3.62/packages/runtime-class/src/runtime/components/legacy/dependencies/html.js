var Template = require("../../../html").Template;
var patch = require("./").patch;
patch(Template);
