module.exports = require("@internal/components-entry");
