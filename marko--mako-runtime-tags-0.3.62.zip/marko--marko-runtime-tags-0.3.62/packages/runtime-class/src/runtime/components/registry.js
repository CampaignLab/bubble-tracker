module.exports = require("@internal/components-registry");
