window.Marko = {
  Component: function () {},
};
