globalThis.Marko = {
  Component: function () {},
};
