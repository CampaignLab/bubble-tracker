var w10NOOP = require("warp10/constants").NOOP;
exports.___noop = w10NOOP;
exports.___toJSON = function () {
  return w10NOOP;
};
