exports.s = require("./runtime-html.js").p(
  require("@marko/runtime-tags/html").compat,
);
