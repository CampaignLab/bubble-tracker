import { compat } from "@marko/runtime-tags/debug/dom";

import { p } from "./runtime-dom.js";
p(compat);
