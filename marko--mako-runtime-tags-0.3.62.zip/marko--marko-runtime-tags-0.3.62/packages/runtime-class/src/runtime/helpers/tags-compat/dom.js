require("./runtime-dom.js").p(require("@marko/runtime-tags/dom").compat);
