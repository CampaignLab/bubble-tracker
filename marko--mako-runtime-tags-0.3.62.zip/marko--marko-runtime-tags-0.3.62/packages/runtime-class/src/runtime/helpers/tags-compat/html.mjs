import { compat } from "@marko/runtime-tags/html";

import { p } from "./runtime-html.js";
export const s = p(compat);
