var arr = [];
module.exports = function (v) {
  return v || arr;
};
