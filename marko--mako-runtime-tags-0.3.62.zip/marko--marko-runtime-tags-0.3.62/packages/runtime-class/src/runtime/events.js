var EventEmitter = require("events-light");
module.exports = new EventEmitter();
