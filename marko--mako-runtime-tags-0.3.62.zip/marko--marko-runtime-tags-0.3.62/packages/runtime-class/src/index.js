"use strict";

exports.createOut = require("./runtime/createOut");
exports.load = require("@internal/loader");
