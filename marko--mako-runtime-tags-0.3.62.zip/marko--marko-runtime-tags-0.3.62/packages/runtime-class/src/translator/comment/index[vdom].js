export default function (path) {
  path.remove();
}
