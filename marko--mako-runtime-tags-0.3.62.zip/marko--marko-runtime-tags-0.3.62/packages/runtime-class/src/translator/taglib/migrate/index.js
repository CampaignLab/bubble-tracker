import * as migrateAllTemplates from "./all-templates";
export default {
  "taglib-id": "marko-default-migrate",
  migrator: migrateAllTemplates,
};
