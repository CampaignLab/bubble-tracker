import noUpdatePlugin from "./no-update";
import scopedPlugin from "./scoped";

export default {
  scoped: scopedPlugin,
  "no-update": noUpdatePlugin,
};
