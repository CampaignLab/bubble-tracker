export const HAS_SIMPLE_ATTRS = 1;
export const IS_CUSTOM_ELEMENT = 2; // TODO: impl custom elements.
export const SPREAD_ATTRS = 4; // TODO: impl custom elements.
