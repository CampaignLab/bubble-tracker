module.exports = require("./dist/register");
