module.exports = require("./dist/config").default;
