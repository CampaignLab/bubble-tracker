module.exports = {
  fs: undefined,
  onError: (err) => {
    throw err;
  },
};
