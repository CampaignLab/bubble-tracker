"use strict";

class Property {
  constructor() {
    this.name = null;
    this.type = "string";
    this.value = undefined;
  }
}

module.exports = Property;
