---
name: "\U00002753Support Question"
about: If you have a question, please check out our Discord or StackOverflow!
title: ""
labels: "type:question"
---

<!--
We primarily use GitHub as an issue tracker; for usage and support questions, please check out these resources below. Thanks!

* Website: https://markojs.com/
* Chat: https://discord.gg/RFGxYGs
* StackOverflow: https://stackoverflow.com/questions/tagged/marko using the tag `marko`
-->
