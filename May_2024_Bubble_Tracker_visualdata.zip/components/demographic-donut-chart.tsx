"use client"
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from "chart.js"
import { Doughnut } from "react-chartjs-2"

// Register required chart components
ChartJS.register(ArcElement, Tooltip, Legend)

// Sample data for demographic breakdown
const demographicData = {
  labels: ["18-29", "30-44", "45-64", "65+"],
  datasets: [
    {
      label: "Voter Demographics",
      data: [18, 26, 35, 21],
      backgroundColor: [
        "rgba(59, 130, 246, 0.8)", // blue
        "rgba(16, 185, 129, 0.8)", // green
        "rgba(245, 158, 11, 0.8)", // amber
        "rgba(239, 68, 68, 0.8)", // red
      ],
      borderColor: ["rgb(59, 130, 246)", "rgb(16, 185, 129)", "rgb(245, 158, 11)", "rgb(239, 68, 68)"],
      borderWidth: 1,
    },
  ],
}

// Chart options
const options = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: "bottom",
      labels: {
        usePointStyle: true,
        padding: 20,
      },
    },
    tooltip: {
      callbacks: {
        label: (context) => {
          const label = context.label || ""
          const value = context.raw
          const total = context.dataset.data.reduce((a, b) => a + b, 0)
          const percentage = Math.round((value / total) * 100)
          return `${label}: ${percentage}% (${value}M voters)`
        },
      },
    },
  },
  cutout: "60%",
  animation: {
    animateScale: true,
    animateRotate: true,
  },
}

export default function DemographicDonutChart() {
  return (
    <div className="w-full h-full flex items-center justify-center">
      <div className="w-full h-full max-h-[350px]">
        <Doughnut data={demographicData} options={options} />
      </div>
    </div>
  )
}

