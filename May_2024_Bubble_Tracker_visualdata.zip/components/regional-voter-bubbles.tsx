"use client"

import type React from "react"

import { useEffect, useRef, useState } from "react"
import { useToast } from "@/hooks/use-toast"
import { Maximize2, Minimize2, ZoomIn, ZoomOut, Compass } from "lucide-react"
import { Button } from "@/components/ui/button"

// Type definition for the Local Authority District data
type LocalAuthorityDistrict = {
  FID: string
  LAD24CD: string
  LAD24NM: string
  LAD24NMW: string | null
  BNG_E: string
  BNG_N: string
  LONG: string
  LAT: string
  Shape__Area: number
  Shape__Length: number
  // Added properties for visualization
  voterCount?: number
  turnout?: number
  bubbles?: Array<{
    x: number
    y: number
    radius: number
    color: string
    turnout: number
    age: string
    isNorth?: boolean
  }>
  isLondon?: boolean
  isNorth?: boolean
}

// London boroughs data with approximate coordinates and north/south classification
const londonBoroughs = [
  { name: "City of London", code: "E09000001", isNorth: false },
  { name: "Barking and Dagenham", code: "E09000002", isNorth: false },
  { name: "Barnet", code: "E09000003", isNorth: true },
  { name: "Bexley", code: "E09000004", isNorth: false },
  { name: "Brent", code: "E09000005", isNorth: true },
  { name: "Bromley", code: "E09000006", isNorth: false },
  { name: "Camden", code: "E09000007", isNorth: true },
  { name: "Croydon", code: "E09000008", isNorth: false },
  { name: "Ealing", code: "E09000009", isNorth: true },
  { name: "Enfield", code: "E09000010", isNorth: true },
  { name: "Greenwich", code: "E09000011", isNorth: false },
  { name: "Hackney", code: "E09000012", isNorth: true },
  { name: "Hammersmith and Fulham", code: "E09000013", isNorth: true },
  { name: "Haringey", code: "E09000014", isNorth: true },
  { name: "Harrow", code: "E09000015", isNorth: true },
  { name: "Havering", code: "E09000016", isNorth: false },
  { name: "Hillingdon", code: "E09000017", isNorth: true },
  { name: "Hounslow", code: "E09000018", isNorth: true },
  { name: "Islington", code: "E09000019", isNorth: true },
  { name: "Kensington and Chelsea", code: "E09000020", isNorth: true },
  { name: "Kingston upon Thames", code: "E09000021", isNorth: false },
  { name: "Lambeth", code: "E09000022", isNorth: false },
  { name: "Lewisham", code: "E09000023", isNorth: false },
  { name: "Merton", code: "E09000024", isNorth: false },
  { name: "Newham", code: "E09000025", isNorth: false },
  { name: "Redbridge", code: "E09000026", isNorth: true },
  { name: "Richmond upon Thames", code: "E09000027", isNorth: false },
  { name: "Southwark", code: "E09000028", isNorth: false },
  { name: "Sutton", code: "E09000029", isNorth: false },
  { name: "Tower Hamlets", code: "E09000030", isNorth: false },
  { name: "Waltham Forest", code: "E09000031", isNorth: true },
  { name: "Wandsworth", code: "E09000032", isNorth: false },
  { name: "Westminster", code: "E09000033", isNorth: true },
]

// High contrast, color-blind friendly palette (using ColorBrewer's colorblind-friendly schemes)
const accessibleColors = {
  // North London boroughs
  north: [
    "#1b9e77", // teal
    "#d95f02", // orange
    "#7570b3", // purple
    "#e7298a", // pink
    "#66a61e", // green
    "#e6ab02", // yellow
    "#a6761d", // brown
  ],
  // South London boroughs
  south: [
    "#e41a1c", // red
    "#377eb8", // blue
    "#4daf4a", // green
    "#984ea3", // purple
    "#ff7f00", // orange
    "#ffff33", // yellow
    "#a65628", // brown
  ],
}

// Age group colors (high contrast for accessibility)
const ageGroupColors = {
  "18-29": "#0072B2", // blue (colorblind friendly)
  "30-44": "#D55E00", // vermillion (colorblind friendly)
  "45-64": "#CC79A7", // reddish purple (colorblind friendly)
  "65+": "#009E73", // bluish green (colorblind friendly)
}

// Color mapping for voter turnout (high contrast for accessibility)
function getTurnoutColor(turnout: number, isNorth: boolean): string {
  const baseColors = isNorth ? accessibleColors.north : accessibleColors.south

  if (turnout >= 70) return baseColors[0]
  if (turnout >= 65) return baseColors[1]
  if (turnout >= 60) return baseColors[2]
  if (turnout >= 55) return baseColors[3]
  return baseColors[4]
}

export default function RegionalVoterBubbles() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const [districts, setDistricts] = useState<LocalAuthorityDistrict[]>([])
  const [londonDistricts, setLondonDistricts] = useState<LocalAuthorityDistrict[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [hoveredDistrict, setHoveredDistrict] = useState<string | null>(null)
  const [selectedDistrict, setSelectedDistrict] = useState<string | null>(null)
  const [tooltipPosition, setTooltipPosition] = useState({ x: 0, y: 0 })
  const [zoomLevel, setZoomLevel] = useState(1)
  const [panOffset, setPanOffset] = useState({ x: 0, y: 0 })
  const [isDragging, setIsDragging] = useState(false)
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 })
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [compassRotation, setCompassRotation] = useState(0)
  const { toast } = useToast()

  // Fetch the Local Authority Districts data
  useEffect(() => {
    async function fetchData() {
      try {
        setLoading(true)
        const response = await fetch(
          "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Local_Authority_Districts_May_2024_Boundaries_UK-0kq44IUMv02CTix2FMtRCABYbvOHx3.csv",
        )

        if (!response.ok) {
          throw new Error(`Failed to fetch data: ${response.status} ${response.statusText}`)
        }

        const csvText = await response.text()
        const parsedData = parseCSV(csvText)

        // Process the data to add voter information
        const processedData = processDistrictData(parsedData)
        setDistricts(processedData)

        // Filter London districts
        const london = processedData.filter((district) =>
          londonBoroughs.some((borough) => borough.code === district.LAD24CD),
        )

        setLondonDistricts(london)
      } catch (err) {
        console.error("Error fetching data:", err)
        setError(err instanceof Error ? err.message : "Unknown error occurred")
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  // Parse CSV data
  function parseCSV(csvText: string): LocalAuthorityDistrict[] {
    const lines = csvText.split("\n")
    const headers = lines[0].split(",")

    return lines
      .slice(1)
      .filter((line) => line.trim() !== "")
      .map((line) => {
        const values = line.split(",")
        const district: any = {}

        headers.forEach((header, index) => {
          const value = values[index]
          if (header === "Shape__Area" || header === "Shape__Length") {
            district[header] = Number.parseFloat(value)
          } else {
            district[header] = value
          }
        })

        // Check if this is a London borough and if it's in North London
        const boroughInfo = londonBoroughs.find((borough) => borough.code === district.LAD24CD)
        district.isLondon = !!boroughInfo
        district.isNorth = boroughInfo?.isNorth || false

        return district as LocalAuthorityDistrict
      })
  }

  // Process district data to add voter information and bubbles
  function processDistrictData(districts: LocalAuthorityDistrict[]): LocalAuthorityDistrict[] {
    return districts.map((district) => {
      // Generate random voter count based on area (just for demonstration)
      const areaFactor = district.Shape__Area / 1000000
      const baseVoterCount = Math.floor(areaFactor * (Math.random() * 5 + 5)) * 1000
      const voterCount = Math.min(Math.max(baseVoterCount, 10000), 500000)

      // Generate random turnout between 50% and 75%
      const turnout = Math.floor(Math.random() * 25 + 50)

      // Generate bubbles for this district (minimum 219 as requested)
      const bubbleCount = Math.max(219, Math.floor(voterCount / 1000))
      const bubbles = []

      // Generate bubbles for all districts
      const ageGroups = Object.keys(ageGroupColors)
      const isNorth = district.isNorth

      // Create dispersion pattern based on north/south
      const dispersionFactor = isNorth ? 0.04 : 0.035 // Slightly different dispersion for north/south

      for (let i = 0; i < bubbleCount; i++) {
        // Create a more concentrated pattern around the center
        const angle = Math.random() * Math.PI * 2
        const distance = Math.pow(Math.random(), 0.5) * dispersionFactor // Square root for more concentration

        const offsetX = Math.cos(angle) * distance
        const offsetY = Math.sin(angle) * distance

        // Random age group
        const ageGroup = ageGroups[Math.floor(Math.random() * ageGroups.length)]

        // Random turnout variation around district average
        const individualTurnout = Math.min(Math.max(turnout + (Math.random() - 0.5) * 20, 30), 90)

        bubbles.push({
          x: Number.parseFloat(district.LONG) + offsetX,
          y: Number.parseFloat(district.LAT) + offsetY,
          radius: Math.random() * 1.5 + 0.8, // Random size between 0.8-2.3
          color: ageGroupColors[ageGroup as keyof typeof ageGroupColors],
          turnout: individualTurnout,
          age: ageGroup,
          isNorth: isNorth,
        })
      }

      return {
        ...district,
        voterCount,
        turnout,
        bubbles,
        isNorth,
      }
    })
  }

  // Toggle fullscreen mode
  const toggleFullscreen = () => {
    if (!containerRef.current) return

    if (!isFullscreen) {
      if (containerRef.current.requestFullscreen) {
        containerRef.current.requestFullscreen()
      }
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen()
      }
    }
  }

  // Handle fullscreen change events
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement)
    }

    document.addEventListener("fullscreenchange", handleFullscreenChange)
    return () => {
      document.removeEventListener("fullscreenchange", handleFullscreenChange)
    }
  }, [])

  // Zoom in function
  const zoomIn = () => {
    setZoomLevel((prev) => Math.min(prev + 0.2, 3))
    // Rotate compass slightly for visual feedback
    setCompassRotation((prev) => prev + 15)
  }

  // Zoom out function
  const zoomOut = () => {
    setZoomLevel((prev) => Math.max(prev - 0.2, 0.5))
    // Rotate compass slightly for visual feedback
    setCompassRotation((prev) => prev - 15)
  }

  // Reset view function
  const resetView = () => {
    setZoomLevel(1)
    setPanOffset({ x: 0, y: 0 })
    setCompassRotation(0)
  }

  // Handle mouse down for panning
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    setIsDragging(true)
    setDragStart({ x: e.clientX, y: e.clientY })
  }

  // Handle mouse move for panning
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current
    if (!canvas) return

    if (isDragging) {
      // Calculate pan distance
      const dx = e.clientX - dragStart.x
      const dy = e.clientY - dragStart.y

      // Update pan offset
      setPanOffset((prev) => ({
        x: prev.x + dx / zoomLevel,
        y: prev.y + dy / zoomLevel,
      }))

      // Update drag start position
      setDragStart({ x: e.clientX, y: e.clientY })

      // Rotate compass based on pan direction
      const panAngle = Math.atan2(dy, dx) * (180 / Math.PI)
      setCompassRotation((prev) => (prev + panAngle / 10) % 360)

      return
    }

    // Handle hover effects when not dragging
    const rect = canvas.getBoundingClientRect()
    const x = ((e.clientX - rect.left) * (canvas.width / rect.width / 2) - panOffset.x * zoomLevel) / zoomLevel
    const y = ((e.clientY - rect.top) * (canvas.height / rect.height / 2) - panOffset.y * zoomLevel) / zoomLevel

    // Find bounds of London data for scaling
    const { minLong, maxLong, minLat, maxLat } = calculateBounds()

    // Function to convert geo coordinates to canvas coordinates
    const geoToCanvas = (long: number, lat: number, canvasWidth: number, canvasHeight: number) => {
      // Flip Y axis since canvas Y increases downward but latitude increases upward
      const x = ((long - minLong) / (maxLong - minLong)) * canvasWidth
      const y = canvasHeight - ((lat - minLat) / (maxLat - minLat)) * canvasHeight
      return { x, y }
    }

    // Check if mouse is over any district
    let found = false
    const canvasWidth = isFullscreen ? 1898 : 1024
    const canvasHeight = isFullscreen ? 1080 : 935

    for (const district of londonDistricts) {
      if (!district.LONG || !district.LAT) continue

      const { x: districtX, y: districtY } = geoToCanvas(
        Number.parseFloat(district.LONG),
        Number.parseFloat(district.LAT),
        canvasWidth,
        canvasHeight,
      )

      const dx = x - districtX
      const dy = y - districtY
      const distance = Math.sqrt(dx * dx + dy * dy)
      const radius = Math.sqrt((district.voterCount || 10000) / 5000) * 5

      if (distance <= radius) {
        setHoveredDistrict(district.LAD24NM)
        setTooltipPosition({ x: e.clientX, y: e.clientY })
        found = true
        break
      }
    }

    if (!found && hoveredDistrict !== null) {
      setHoveredDistrict(null)
    }
  }

  // Handle mouse up to end panning
  const handleMouseUp = () => {
    setIsDragging(false)
  }

  // Handle mouse leave to end panning
  const handleMouseLeave = () => {
    setIsDragging(false)
  }

  // Handle wheel for zooming
  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault()

    // Zoom in or out based on wheel direction
    if (e.deltaY < 0) {
      zoomIn()
    } else {
      zoomOut()
    }
  }

  // Calculate bounds of London data
  const calculateBounds = () => {
    let minLong = Number.POSITIVE_INFINITY,
      maxLong = Number.NEGATIVE_INFINITY,
      minLat = Number.POSITIVE_INFINITY,
      maxLat = Number.NEGATIVE_INFINITY

    londonDistricts.forEach((district) => {
      const long = Number.parseFloat(district.LONG)
      const lat = Number.parseFloat(district.LAT)

      if (long < minLong) minLong = long
      if (long > maxLong) maxLong = long
      if (lat < minLat) minLat = lat
      if (lat > maxLat) maxLat = lat
    })

    // Add padding to bounds
    const paddingFactor = 0.1
    const longRange = maxLong - minLong
    const latRange = maxLat - minLat

    minLong -= longRange * paddingFactor
    maxLong += longRange * paddingFactor
    minLat -= latRange * paddingFactor
    maxLat += latRange * paddingFactor

    return { minLong, maxLong, minLat, maxLat }
  }

  // Function to draw the London map
  const drawLondonMap = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions based on fullscreen state
    const canvasWidth = isFullscreen ? 1898 : 1024
    const canvasHeight = isFullscreen ? 1080 : 935

    canvas.width = canvasWidth * 2 // Double for retina display
    canvas.height = canvasHeight * 2
    canvas.style.width = `${canvasWidth}px`
    canvas.style.height = `${canvasHeight}px`
    ctx.scale(2, 2)

    // Clear canvas
    ctx.clearRect(0, 0, canvasWidth, canvasHeight)

    // Draw background
    ctx.fillStyle = "#f8fafc" // very light gray background
    ctx.fillRect(0, 0, canvasWidth, canvasHeight)

    if (loading || londonDistricts.length === 0) {
      // Draw loading state
      ctx.fillStyle = "#64748b"
      ctx.font = "16px sans-serif"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(loading ? "Loading London data..." : "No London data available", canvasWidth / 2, canvasHeight / 2)
      return
    }

    // Save the current context state
    ctx.save()

    // Apply zoom and pan transformations
    ctx.translate(panOffset.x * zoomLevel, panOffset.y * zoomLevel)
    ctx.scale(zoomLevel, zoomLevel)

    // Calculate the bounds for the London data
    const { minLong, maxLong, minLat, maxLat } = calculateBounds()

    // Function to convert geo coordinates to canvas coordinates
    const geoToCanvas = (long: number, lat: number) => {
      // Flip Y axis since canvas Y increases downward but latitude increases upward
      const x = ((long - minLong) / (maxLong - minLong)) * canvasWidth
      const y = canvasHeight - ((lat - minLat) / (maxLat - minLat)) * canvasHeight
      return { x, y }
    }

    // Draw Thames river path (simplified)
    ctx.beginPath()
    ctx.moveTo(canvasWidth * 0.1, canvasHeight * 0.5) // West
    ctx.bezierCurveTo(
      canvasWidth * 0.3,
      canvasHeight * 0.48,
      canvasWidth * 0.5,
      canvasHeight * 0.52,
      canvasWidth * 0.7,
      canvasHeight * 0.5,
    )
    ctx.bezierCurveTo(
      canvasWidth * 0.8,
      canvasHeight * 0.48,
      canvasWidth * 0.9,
      canvasHeight * 0.52,
      canvasWidth * 0.95,
      canvasHeight * 0.5,
    )
    ctx.lineWidth = 6
    ctx.strokeStyle = "#bfdbfe" // light blue
    ctx.stroke()

    // Fill river
    ctx.lineWidth = 12
    ctx.strokeStyle = "#93c5fd" // blue
    ctx.stroke()

    // Draw borough markers
    londonDistricts.forEach((district) => {
      if (!district.LONG || !district.LAT) return

      const { x, y } = geoToCanvas(Number.parseFloat(district.LONG), Number.parseFloat(district.LAT))

      // Draw district marker
      const isActive = hoveredDistrict === district.LAD24NM || selectedDistrict === district.LAD24NM
      const turnoutColor = district.turnout ? getTurnoutColor(district.turnout, district.isNorth || false) : "#64748b"

      // Draw district circle
      ctx.beginPath()
      const radius = Math.sqrt((district.voterCount || 10000) / 5000) * 5 // Larger bubbles for better visibility
      ctx.arc(x, y, radius, 0, Math.PI * 2)

      // Use semi-transparent fill for better accessibility
      ctx.fillStyle = isActive
        ? `${turnoutColor}cc` // More opaque when active
        : `${turnoutColor}99` // Semi-transparent
      ctx.fill()

      ctx.strokeStyle = turnoutColor
      ctx.lineWidth = isActive ? 3 : 2
      ctx.stroke()

      // Draw borough first letter
      ctx.fillStyle = "#000000" // Black text for contrast
      ctx.font = isActive ? "bold 16px sans-serif" : "bold 14px sans-serif"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"

      // Get first letter of borough name
      const firstLetter = district.LAD24NM.charAt(0)
      ctx.fillText(firstLetter, x, y)

      // Draw full borough name for active districts
      if (isActive) {
        ctx.fillStyle = "#000000"
        ctx.font = "bold 14px sans-serif"
        ctx.textAlign = "center"
        ctx.textBaseline = "bottom"

        // Add white background for better readability
        const textWidth = ctx.measureText(district.LAD24NM).width
        ctx.fillStyle = "rgba(255, 255, 255, 0.8)"
        ctx.fillRect(x - textWidth / 2 - 4, y - radius - 25, textWidth + 8, 20)

        ctx.fillStyle = "#000000"
        ctx.fillText(district.LAD24NM, x, y - radius - 10)

        // Indicate if North or South London
        const regionText = district.isNorth ? "North London" : "South London"
        ctx.font = "bold 12px sans-serif"
        ctx.fillStyle = district.isNorth ? "#1b9e77" : "#e41a1c"
        ctx.fillText(regionText, x, y - radius - 30)
      }

      // Draw voter bubbles if this district has them
      if (district.bubbles && district.bubbles.length > 0) {
        district.bubbles.forEach((bubble) => {
          const bubblePos = geoToCanvas(bubble.x, bubble.y)

          ctx.beginPath()
          ctx.arc(bubblePos.x, bubblePos.y, bubble.radius, 0, Math.PI * 2)

          // Use semi-transparent fill for better visibility
          ctx.fillStyle = `${bubble.color}80`
          ctx.fill()

          ctx.strokeStyle = bubble.color
          ctx.lineWidth = 0.5
          ctx.stroke()
        })
      }
    })

    // Restore the context state
    ctx.restore()

    // Draw legend (fixed position, not affected by zoom/pan)
    const legendX = 20
    const legendY = 20
    const legendWidth = 220
    const legendHeight = 240

    // Legend background
    ctx.fillStyle = "rgba(255, 255, 255, 0.9)"
    ctx.fillRect(legendX, legendY, legendWidth, legendHeight)
    ctx.strokeStyle = "#e2e8f0"
    ctx.lineWidth = 1
    ctx.strokeRect(legendX, legendY, legendWidth, legendHeight)

    // Legend title
    ctx.fillStyle = "#1e293b"
    ctx.font = "bold 16px sans-serif"
    ctx.textAlign = "left"
    ctx.textBaseline = "middle"
    ctx.fillText("London Voter Data", legendX + 10, legendY + 20)

    // Legend subtitle
    ctx.fillStyle = "#64748b"
    ctx.font = "bold 12px sans-serif"
    ctx.fillText("33 London Boroughs", legendX + 10, legendY + 45)
    ctx.fillText("Minimum 219 bubbles per borough", legendX + 10, legendY + 65)

    // North/South London legend
    ctx.fillStyle = "#1e293b"
    ctx.font = "bold 14px sans-serif"
    ctx.fillText("Region:", legendX + 10, legendY + 90)

    // North London
    ctx.beginPath()
    ctx.arc(legendX + 20, legendY + 110, 8, 0, Math.PI * 2)
    ctx.fillStyle = `${accessibleColors.north[0]}cc`
    ctx.fill()
    ctx.strokeStyle = accessibleColors.north[0]
    ctx.lineWidth = 2
    ctx.stroke()

    ctx.fillStyle = "#1e293b"
    ctx.font = "bold 12px sans-serif"
    ctx.textAlign = "left"
    ctx.fillText("North London", legendX + 35, legendY + 110)

    // South London
    ctx.beginPath()
    ctx.arc(legendX + 20, legendY + 130, 8, 0, Math.PI * 2)
    ctx.fillStyle = `${accessibleColors.south[0]}cc`
    ctx.fill()
    ctx.strokeStyle = accessibleColors.south[0]
    ctx.lineWidth = 2
    ctx.stroke()

    ctx.fillStyle = "#1e293b"
    ctx.font = "bold 12px sans-serif"
    ctx.textAlign = "left"
    ctx.fillText("South London", legendX + 35, legendY + 130)

    // Age groups legend
    ctx.fillStyle = "#1e293b"
    ctx.font = "bold 14px sans-serif"
    ctx.fillText("Age Groups:", legendX + 10, legendY + 155)

    Object.entries(ageGroupColors).forEach(([group, color], i) => {
      const y = legendY + 175 + i * 20

      ctx.beginPath()
      ctx.arc(legendX + 20, y, 6, 0, Math.PI * 2)
      ctx.fillStyle = `${color}80`
      ctx.fill()
      ctx.strokeStyle = color
      ctx.lineWidth = 1
      ctx.stroke()

      ctx.fillStyle = "#1e293b"
      ctx.font = "bold 12px sans-serif"
      ctx.textAlign = "left"
      ctx.fillText(group, legendX + 35, y)
    })

    // Draw compass (fixed position, not affected by zoom/pan)
    const compassX = canvasWidth - 80
    const compassY = 80
    const compassRadius = 40

    // Compass background
    ctx.beginPath()
    ctx.arc(compassX, compassY, compassRadius, 0, Math.PI * 2)
    ctx.fillStyle = "rgba(255, 255, 255, 0.9)"
    ctx.fill()
    ctx.strokeStyle = "#64748b"
    ctx.lineWidth = 2
    ctx.stroke()

    // Save context for compass rotation
    ctx.save()
    ctx.translate(compassX, compassY)
    ctx.rotate((compassRotation * Math.PI) / 180)

    // Draw compass directions
    const directions = ["N", "E", "S", "W"]
    directions.forEach((dir, i) => {
      const angle = (i * Math.PI) / 2
      const x = Math.sin(angle) * (compassRadius - 15)
      const y = -Math.cos(angle) * (compassRadius - 15)

      ctx.fillStyle = "#1e293b"
      ctx.font = "bold 14px sans-serif"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(dir, x, y)
    })

    // Draw compass needle
    ctx.beginPath()
    ctx.moveTo(0, -compassRadius + 10)
    ctx.lineTo(0, compassRadius - 10)
    ctx.strokeStyle = "#ef4444" // Red for north-south line
    ctx.lineWidth = 2
    ctx.stroke()

    ctx.beginPath()
    ctx.moveTo(-compassRadius + 10, 0)
    ctx.lineTo(compassRadius - 10, 0)
    ctx.strokeStyle = "#3b82f6" // Blue for east-west line
    ctx.lineWidth = 2
    ctx.stroke()

    // Draw compass center
    ctx.beginPath()
    ctx.arc(0, 0, 5, 0, Math.PI * 2)
    ctx.fillStyle = "#1e293b"
    ctx.fill()

    // Restore context after compass rotation
    ctx.restore()

    // Draw selected district info
    if (selectedDistrict) {
      const district = londonDistricts.find((d) => d.LAD24NM === selectedDistrict)
      if (district) {
        const infoX = canvasWidth - 240
        const infoY = 140
        const infoWidth = 220
        const infoHeight = 180

        // Info background
        ctx.fillStyle = "rgba(255, 255, 255, 0.9)"
        ctx.fillRect(infoX, infoY, infoWidth, infoHeight)
        ctx.strokeStyle = "#e2e8f0"
        ctx.lineWidth = 1
        ctx.strokeRect(infoX, infoY, infoWidth, infoHeight)

        // District name
        ctx.fillStyle = "#1e293b"
        ctx.font = "bold 16px sans-serif"
        ctx.textAlign = "left"
        ctx.textBaseline = "middle"
        ctx.fillText(district.LAD24NM, infoX + 10, infoY + 20)

        // Region indicator
        ctx.fillStyle = district.isNorth ? "#1b9e77" : "#e41a1c"
        ctx.font = "bold 14px sans-serif"
        ctx.fillText(district.isNorth ? "North London" : "South London", infoX + 10, infoY + 45)

        // District code
        ctx.fillStyle = "#64748b"
        ctx.font = "bold 12px sans-serif"
        ctx.fillText(`Code: ${district.LAD24CD}`, infoX + 10, infoY + 70)

        // Voter information
        ctx.fillText(`Estimated voters: ${district.voterCount?.toLocaleString()}`, infoX + 10, infoY + 95)
        ctx.fillText(`Average turnout: ${district.turnout}%`, infoX + 10, infoY + 120)

        // Bubble count
        const bubbleCount = district.bubbles?.length || 0
        ctx.fillText(`Bubble count: ${bubbleCount}`, infoX + 10, infoY + 145)
      }
    }
  }

  // Handle click on districts
  const handleClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (isDragging) return

    if (hoveredDistrict !== null) {
      setSelectedDistrict(hoveredDistrict === selectedDistrict ? null : hoveredDistrict)

      const district = londonDistricts.find((d) => d.LAD24NM === hoveredDistrict)
      if (district) {
        toast({
          title: district.LAD24NM,
          description: `${district.isNorth ? "North" : "South"} London, Code: ${district.LAD24CD}, Estimated voters: ${district.voterCount?.toLocaleString()}, Average turnout: ${district.turnout}%`,
        })
      }
    } else {
      setSelectedDistrict(null)
    }
  }

  // Draw map when data or selection changes
  useEffect(() => {
    drawLondonMap()

    const handleResize = () => {
      drawLondonMap()
    }

    window.addEventListener("resize", handleResize)
    return () => {
      window.removeEventListener("resize", handleResize)
    }
  }, [
    londonDistricts,
    hoveredDistrict,
    selectedDistrict,
    loading,
    error,
    zoomLevel,
    panOffset,
    isFullscreen,
    compassRotation,
  ])

  if (error) {
    return (
      <div className="w-full h-full flex items-center justify-center">
        <div className="text-destructive text-center">
          <p className="font-bold">Error loading data</p>
          <p className="text-sm">{error}</p>
        </div>
      </div>
    )
  }

  return (
    <div ref={containerRef} className="relative w-full h-full flex items-center justify-center overflow-hidden">
      <canvas
        ref={canvasRef}
        className="cursor-move max-w-full max-h-full object-contain"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseLeave}
        onClick={handleClick}
        onWheel={handleWheel}
      />

      {hoveredDistrict !== null && !isDragging && (
        <div
          className="absolute z-50 bg-background border rounded-md shadow-md p-2 text-sm pointer-events-none"
          style={{
            left: `${tooltipPosition.x + 10}px`,
            top: `${tooltipPosition.y + 10}px`,
            transform: "translateX(-50%)",
          }}
        >
          {(() => {
            const district = londonDistricts.find((d) => d.LAD24NM === hoveredDistrict)
            return district ? (
              <div>
                <div className="font-bold">{district.LAD24NM}</div>
                <div className="font-semibold" style={{ color: district.isNorth ? "#1b9e77" : "#e41a1c" }}>
                  {district.isNorth ? "North London" : "South London"}
                </div>
                <div>Code: {district.LAD24CD}</div>
                <div>Estimated voters: {district.voterCount?.toLocaleString()}</div>
                <div>Average turnout: {district.turnout}%</div>
                <div>Bubble count: {district.bubbles?.length || 0}</div>
              </div>
            ) : null
          })()}
        </div>
      )}

      <div className="absolute bottom-4 left-4 text-xs font-bold text-muted-foreground">
        Click on a borough to see detailed information
      </div>

      {/* Controls */}
      <div className="absolute top-4 right-4 flex flex-col gap-2">
        <Button
          variant="outline"
          size="icon"
          onClick={toggleFullscreen}
          className="bg-white/90 shadow-md"
          title={isFullscreen ? "Exit fullscreen" : "Enter fullscreen"}
        >
          {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
        </Button>

        <Button variant="outline" size="icon" onClick={zoomIn} className="bg-white/90 shadow-md" title="Zoom in">
          <ZoomIn className="h-4 w-4" />
        </Button>

        <Button variant="outline" size="icon" onClick={zoomOut} className="bg-white/90 shadow-md" title="Zoom out">
          <ZoomOut className="h-4 w-4" />
        </Button>

        <Button variant="outline" size="icon" onClick={resetView} className="bg-white/90 shadow-md" title="Reset view">
          <Compass className="h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}

