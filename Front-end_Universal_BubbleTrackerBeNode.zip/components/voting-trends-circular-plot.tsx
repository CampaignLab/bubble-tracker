"use client"

import { useState, useEffect, useRef } from "react"
import { useToast } from "@/hooks/use-toast"
import { BarChartIcon, PieChart, ArrowRight, Info } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { useMobile } from "@/hooks/use-mobile"

// Updated data for general elections from 2010 to 2024
const electionData = [
  {
    year: 2010,
    results: [
      { party: "Conservative", votes: 36.1, seats: 306, color: "#0087DC" },
      { party: "Labour", votes: 29.0, seats: 258, color: "#E4003B" },
      { party: "Liberal Democrat", votes: 23.0, seats: 57, color: "#FAA61A" },
      { party: "Other", votes: 11.9, seats: 29, color: "#777777" },
    ],
    turnout: 65.1,
    outcome: "Conservative-Lib Dem Coalition",
  },
  {
    year: 2015,
    results: [
      { party: "Conservative", votes: 36.9, seats: 330, color: "#0087DC" },
      { party: "Labour", votes: 30.4, seats: 232, color: "#E4003B" },
      { party: "UKIP", votes: 12.6, seats: 1, color: "#70147A" },
      { party: "Liberal Democrat", votes: 7.9, seats: 8, color: "#FAA61A" },
      { party: "SNP", votes: 4.7, seats: 56, color: "#FFF95D" },
      { party: "Green", votes: 3.8, seats: 1, color: "#6AB023" },
      { party: "Other", votes: 3.7, seats: 22, color: "#777777" },
    ],
    turnout: 66.1,
    outcome: "Conservative Majority",
  },
  {
    year: 2017,
    results: [
      { party: "Conservative", votes: 42.4, seats: 317, color: "#0087DC" },
      { party: "Labour", votes: 40.0, seats: 262, color: "#E4003B" },
      { party: "Liberal Democrat", votes: 7.4, seats: 12, color: "#FAA61A" },
      { party: "SNP", votes: 3.0, seats: 35, color: "#FFF95D" },
      { party: "UKIP", votes: 1.8, seats: 0, color: "#70147A" },
      { party: "Green", votes: 1.6, seats: 1, color: "#6AB023" },
      { party: "Other", votes: 3.8, seats: 23, color: "#777777" },
    ],
    turnout: 68.7,
    outcome: "Conservative Minority",
  },
  {
    year: 2019,
    results: [
      { party: "Conservative", votes: 43.6, seats: 365, color: "#0087DC" },
      { party: "Labour", votes: 32.1, seats: 202, color: "#E4003B" },
      { party: "Liberal Democrat", votes: 11.6, seats: 11, color: "#FAA61A" },
      { party: "SNP", votes: 3.9, seats: 48, color: "#FFF95D" },
      { party: "Green", votes: 2.7, seats: 1, color: "#6AB023" },
      { party: "Brexit Party", votes: 2.0, seats: 0, color: "#12B6CF" },
      { party: "Other", votes: 4.1, seats: 23, color: "#777777" },
    ],
    turnout: 67.3,
    outcome: "Conservative Majority",
  },
  {
    year: 2024,
    results: [
      { party: "Labour", votes: 33.7, seats: 412, color: "#E4003B" },
      { party: "Conservative", votes: 24.3, seats: 121, color: "#0087DC" },
      { party: "Liberal Democrat", votes: 12.2, seats: 72, color: "#FAA61A" },
      { party: "Reform UK", votes: 14.3, seats: 4, color: "#12B6CF" },
      { party: "Green", votes: 8.3, seats: 4, color: "#6AB023" },
      { party: "SNP", votes: 2.4, seats: 9, color: "#FFF95D" },
      { party: "Other", votes: 4.8, seats: 28, color: "#777777" },
    ],
    turnout: 60.2,
    outcome: "Labour Majority",
  },
]

// Demographic flow data - connecting demographics to voting patterns
const demographicFlowData = {
  ageGroups: [
    { name: "18-29", value: 21, conservative: 15, labour: 55, libdem: 12, reform: 8, green: 10 },
    { name: "30-44", value: 28, conservative: 25, labour: 45, libdem: 15, reform: 7, green: 8 },
    { name: "45-64", value: 32, conservative: 35, labour: 30, libdem: 12, reform: 18, green: 5 },
    { name: "65+", value: 19, conservative: 45, labour: 20, libdem: 10, reform: 20, green: 5 },
  ],
  regions: [
    { name: "North West", value: 24, conservative: 22, labour: 48, libdem: 10, reform: 15, green: 5 },
    { name: "North East", value: 19, conservative: 18, labour: 52, libdem: 8, reform: 17, green: 5 },
    { name: "Central", value: 22, conservative: 25, labour: 45, libdem: 15, reform: 5, green: 10 },
    { name: "South West", value: 18, conservative: 30, labour: 25, libdem: 25, reform: 10, green: 10 },
    { name: "South East", value: 17, conservative: 35, labour: 30, libdem: 10, reform: 15, green: 10 },
  ],
}

// Party colors for consistency
const partyColors = {
  Conservative: "#0087DC",
  Labour: "#E4003B",
  "Liberal Democrat": "#FAA61A",
  "Reform UK": "#12B6CF",
  Green: "#6AB023",
  SNP: "#FFF95D",
  UKIP: "#70147A",
  "Brexit Party": "#12B6CF",
  Other: "#777777",
}

export default function VotingTrendsBarChart() {
  const [selectedYear, setSelectedYear] = useState<number>(2024)
  const [selectedView, setSelectedView] = useState<"votes" | "seats">("votes")
  const [selectedTab, setSelectedTab] = useState<"elections" | "flow">("elections")
  const barChartRef = useRef<HTMLCanvasElement>(null)
  const flowChartRef = useRef<HTMLCanvasElement>(null)
  const { toast } = useToast()
  const isMobile = useMobile()

  // Filter election data to only include 2017-2024
  const filteredElectionData = electionData.filter((election) => election.year >= 2017)

  // Draw the bar chart with mobile optimizations
  const drawBarChart = () => {
    const canvas = barChartRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions
    const parentWidth = canvas.parentElement?.clientWidth || 600
    const parentHeight = canvas.parentElement?.clientHeight || 400

    // Set the canvas size with higher resolution for retina displays
    canvas.width = parentWidth * 2
    canvas.height = parentHeight * 2
    canvas.style.width = `${parentWidth}px`
    canvas.style.height = `${parentHeight}px`
    ctx.scale(2, 2)

    // Clear canvas
    ctx.clearRect(0, 0, parentWidth, parentHeight)

    // Find the selected election data
    const election = electionData.find((e) => e.year === selectedYear) || electionData[electionData.length - 1]

    // Set chart dimensions - adjust for mobile
    const chartTop = isMobile ? 40 : 60
    const chartBottom = parentHeight - (isMobile ? 40 : 60)
    const chartLeft = isMobile ? 50 : 80
    const chartRight = parentWidth - (isMobile ? 20 : 40)
    const chartHeight = chartBottom - chartTop
    const chartWidth = chartRight - chartLeft

    // Draw title - smaller on mobile
    ctx.fillStyle = "#1e293b"
    ctx.font = isMobile ? "bold 14px sans-serif" : "bold 18px sans-serif"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    ctx.fillText(`${election.year} General Election Results`, parentWidth / 2, isMobile ? 10 : 20)

    // Draw subtitle - smaller or hidden on mobile
    if (!isMobile) {
      ctx.fillStyle = "#64748b"
      ctx.font = "14px sans-serif"
      ctx.fillText(`Turnout: ${election.turnout}% | Outcome: ${election.outcome}`, parentWidth / 2, 45)
    }

    // Get data based on selected view
    const data = election.results.map((result) => ({
      ...result,
      value: selectedView === "votes" ? result.votes : result.seats,
    }))

    // Sort data by value in descending order
    data.sort((a, b) => b.value - a.value)

    // Calculate max value for scaling
    const maxValue = Math.max(...data.map((item) => item.value))
    const valueUnit = selectedView === "votes" ? "%" : " seats"

    // Draw y-axis
    ctx.beginPath()
    ctx.moveTo(chartLeft, chartTop)
    ctx.lineTo(chartLeft, chartBottom)
    ctx.strokeStyle = "#e2e8f0"
    ctx.lineWidth = 2
    ctx.stroke()

    // Draw x-axis
    ctx.beginPath()
    ctx.moveTo(chartLeft, chartBottom)
    ctx.lineTo(chartRight, chartBottom)
    ctx.stroke()

    // Draw y-axis labels and grid lines - fewer steps on mobile
    const ySteps = isMobile ? 3 : 5
    for (let i = 0; i <= ySteps; i++) {
      const value = (maxValue * (ySteps - i)) / ySteps
      const y = chartTop + (i * chartHeight) / ySteps

      // Draw grid line
      ctx.beginPath()
      ctx.moveTo(chartLeft, y)
      ctx.lineTo(chartRight, y)
      ctx.strokeStyle = "#e2e8f0"
      ctx.lineWidth = 1
      ctx.stroke()

      // Draw label - smaller on mobile
      ctx.fillStyle = "#64748b"
      ctx.font = isMobile ? "10px sans-serif" : "12px sans-serif"
      ctx.textAlign = "right"
      ctx.textBaseline = "middle"
      ctx.fillText(value.toFixed(1) + valueUnit, chartLeft - 5, y)
    }

    // Calculate bar width and spacing - adjust for mobile
    // For mobile, limit to top 5 parties if needed
    const displayData = isMobile && data.length > 5 ? data.slice(0, 5) : data
    const barCount = displayData.length
    const barSpacing = isMobile ? 5 : 10
    const totalBarWidth = chartWidth - barSpacing * (barCount + 1)
    const barWidth = totalBarWidth / barCount

    // Draw bars
    displayData.forEach((item, index) => {
      const barHeight = (item.value / maxValue) * chartHeight
      const barLeft = chartLeft + barSpacing + index * (barWidth + barSpacing)
      const barTop = chartBottom - barHeight

      // Draw bar
      ctx.fillStyle = item.color
      ctx.fillRect(barLeft, barTop, barWidth, barHeight)

      // Draw party name - adjust for mobile
      if (isMobile) {
        // For mobile, use abbreviated party names and vertical text
        let shortName = item.party
        if (item.party === "Conservative") shortName = "Con"
        else if (item.party === "Labour") shortName = "Lab"
        else if (item.party === "Liberal Democrat") shortName = "LD"
        else if (item.party === "Reform UK") shortName = "Ref"
        else if (item.party === "Green") shortName = "Grn"

        ctx.fillStyle = "#1e293b"
        ctx.font = "bold 10px sans-serif"
        ctx.textAlign = "center"
        ctx.textBaseline = "top"
        ctx.fillText(shortName, barLeft + barWidth / 2, chartBottom + 5)
      } else {
        // For desktop, use rotated text
        ctx.save()
        ctx.translate(barLeft + barWidth / 2, chartBottom + 10)
        ctx.rotate(Math.PI / 4) // Rotate text for better fit
        ctx.fillStyle = "#1e293b"
        ctx.font = "bold 12px sans-serif"
        ctx.textAlign = "left"
        ctx.textBaseline = "middle"
        ctx.fillText(item.party, 0, 0)
        ctx.restore()
      }

      // Draw value on top of bar - smaller on mobile
      ctx.fillStyle = "#1e293b"
      ctx.font = isMobile ? "bold 10px sans-serif" : "bold 12px sans-serif"
      ctx.textAlign = "center"
      ctx.textBaseline = "bottom"
      ctx.fillText(item.value.toFixed(1), barLeft + barWidth / 2, barTop - 2)
    })

    // Draw legend - simplified for mobile
    if (!isMobile) {
      const legendTop = chartBottom + 60
      const legendItemWidth = 120
      const legendItemHeight = 20
      const legendItemsPerRow = Math.floor(chartWidth / legendItemWidth)

      displayData.forEach((item, index) => {
        const row = Math.floor(index / legendItemsPerRow)
        const col = index % legendItemsPerRow
        const legendX = chartLeft + col * legendItemWidth
        const legendY = legendTop + row * legendItemHeight

        // Draw color box
        ctx.fillStyle = item.color
        ctx.fillRect(legendX, legendY, 15, 15)

        // Draw party name
        ctx.fillStyle = "#1e293b"
        ctx.font = "12px sans-serif"
        ctx.textAlign = "left"
        ctx.textBaseline = "middle"
        ctx.fillText(item.party, legendX + 25, legendY + 7.5)
      })
    }
  }

  // Draw the demographic flow chart - optimized for mobile
  const drawFlowChart = () => {
    const canvas = flowChartRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions
    const parentWidth = canvas.parentElement?.clientWidth || 600
    const parentHeight = canvas.parentElement?.clientHeight || 400

    // Set the canvas size with higher resolution for retina displays
    canvas.width = parentWidth * 2
    canvas.height = parentHeight * 2
    canvas.style.width = `${parentWidth}px`
    canvas.style.height = `${parentHeight}px`
    ctx.scale(2, 2)

    // Clear canvas
    ctx.clearRect(0, 0, parentWidth, parentHeight)

    // Draw title - smaller on mobile
    ctx.fillStyle = "#1e293b"
    ctx.font = isMobile ? "bold 14px sans-serif" : "bold 18px sans-serif"
    ctx.textAlign = "center"
    ctx.textBaseline = "top"
    ctx.fillText("Age-Based Voting Patterns - May 2024", parentWidth / 2, isMobile ? 10 : 20)

    // Skip subtitle on mobile
    if (!isMobile) {
      ctx.fillStyle = "#64748b"
      ctx.font = "14px sans-serif"
      ctx.fillText("How age demographics influenced voting patterns", parentWidth / 2, 45)
    }

    // Set chart dimensions - adjust for mobile
    const chartTop = isMobile ? 40 : 80
    const chartBottom = parentHeight - (isMobile ? 30 : 60)
    const chartHeight = chartBottom - chartTop

    // For mobile, create a simpler age-based flow chart
    if (isMobile) {
      // Draw age groups as horizontal bars with voting patterns
      const ageGroups = demographicFlowData.ageGroups
      const barHeight = (chartHeight / ageGroups.length) * 0.7
      const barSpacing = chartHeight / ageGroups.length - barHeight
      const barWidth = parentWidth - 60

      ageGroups.forEach((group, index) => {
        const y = chartTop + index * (barHeight + barSpacing)

        // Draw age group label
        ctx.fillStyle = "#1e293b"
        ctx.font = "bold 12px sans-serif"
        ctx.textAlign = "right"
        ctx.textBaseline = "middle"
        ctx.fillText(group.name, 40, y + barHeight / 2)

        // Draw multi-segment bar
        let xOffset = 50

        // Calculate total for percentage
        const total = group.conservative + group.labour + group.libdem + group.reform + group.green

        // Draw Conservative segment
        const conWidth = (group.conservative / total) * barWidth
        ctx.fillStyle = partyColors.Conservative
        ctx.fillRect(xOffset, y, conWidth, barHeight)
        xOffset += conWidth

        // Draw Labour segment
        const labWidth = (group.labour / total) * barWidth
        ctx.fillStyle = partyColors.Labour
        ctx.fillRect(xOffset, y, labWidth, barHeight)
        xOffset += labWidth

        // Draw Lib Dem segment
        const ldWidth = (group.libdem / total) * barWidth
        ctx.fillStyle = partyColors["Liberal Democrat"]
        ctx.fillRect(xOffset, y, ldWidth, barHeight)
        xOffset += ldWidth

        // Draw Reform segment
        const refWidth = (group.reform / total) * barWidth
        ctx.fillStyle = partyColors["Reform UK"]
        ctx.fillRect(xOffset, y, refWidth, barHeight)
        xOffset += refWidth

        // Draw Green segment
        const grnWidth = (group.green / total) * barWidth
        ctx.fillStyle = partyColors.Green
        ctx.fillRect(xOffset, y, grnWidth, barHeight)

        // Add percentage labels to larger segments
        xOffset = 50
        if (conWidth > 30) {
          ctx.fillStyle = "#ffffff"
          ctx.font = "bold 10px sans-serif"
          ctx.textAlign = "center"
          ctx.textBaseline = "middle"
          ctx.fillText(`${group.conservative}%`, xOffset + conWidth / 2, y + barHeight / 2)
        }
        xOffset += conWidth

        if (labWidth > 30) {
          ctx.fillStyle = "#ffffff"
          ctx.font = "bold 10px sans-serif"
          ctx.textAlign = "center"
          ctx.textBaseline = "middle"
          ctx.fillText(`${group.labour}%`, xOffset + labWidth / 2, y + barHeight / 2)
        }
        xOffset += labWidth

        if (ldWidth > 30) {
          ctx.fillStyle = "#ffffff"
          ctx.font = "bold 10px sans-serif"
          ctx.textAlign = "center"
          ctx.textBaseline = "middle"
          ctx.fillText(`${group.libdem}%`, xOffset + ldWidth / 2, y + barHeight / 2)
        }
      })

      // Draw legend
      const legendY = chartBottom + 10
      const legendX = 10
      const parties = ["Con", "Lab", "LD", "Ref", "Grn"]
      const colors = [
        partyColors.Conservative,
        partyColors.Labour,
        partyColors["Liberal Democrat"],
        partyColors["Reform UK"],
        partyColors.Green,
      ]

      ctx.font = "10px sans-serif"
      ctx.textBaseline = "middle"

      parties.forEach((party, i) => {
        const x = legendX + i * 50

        // Draw color box
        ctx.fillStyle = colors[i]
        ctx.fillRect(x, legendY, 10, 10)

        // Draw party name
        ctx.fillStyle = "#1e293b"
        ctx.textAlign = "left"
        ctx.fillText(party, x + 15, legendY + 5)
      })

      // Add note about 219 bubbles
      ctx.fillStyle = "#64748b"
      ctx.font = "9px sans-serif"
      ctx.textAlign = "center"
      ctx.fillText("Based on 219+ data points per borough", parentWidth / 2, legendY + 25)
    } else {
      // Desktop version - keep the original flow chart implementation
      // Draw age groups on the left
      const ageGroupWidth = 100
      const ageGroupLeft = 50
      const ageGroupSpacing = chartHeight / demographicFlowData.ageGroups.length
      const ageGroupHeight = ageGroupSpacing * 0.7

      // Draw age group title
      ctx.fillStyle = "#1e293b"
      ctx.font = "bold 14px sans-serif"
      ctx.textAlign = "center"
      ctx.textBaseline = "bottom"
      ctx.fillText("Age Groups", ageGroupLeft + ageGroupWidth / 2, chartTop - 10)

      // Draw age groups
      demographicFlowData.ageGroups.forEach((group, index) => {
        const y = chartTop + index * ageGroupSpacing + ageGroupHeight / 2

        // Draw age group box
        ctx.fillStyle = `rgba(0, 114, 178, ${0.5 + group.value / 100})`
        ctx.fillRect(ageGroupLeft, y - ageGroupHeight / 2, ageGroupWidth, ageGroupHeight)

        // Draw age group label
        ctx.fillStyle = "#ffffff"
        ctx.font = "bold 12px sans-serif"
        ctx.textAlign = "center"
        ctx.textBaseline = "middle"
        ctx.fillText(group.name, ageGroupLeft + ageGroupWidth / 2, y)

        // Draw percentage
        ctx.fillText(`${group.value}%`, ageGroupLeft + ageGroupWidth / 2, y + ageGroupHeight / 4)
      })

      // Draw regions on the right
      const regionWidth = 100
      const regionRight = parentWidth - 50
      const regionLeft = regionRight - regionWidth
      const regionSpacing = chartHeight / demographicFlowData.regions.length
      const regionHeight = regionSpacing * 0.7

      // Draw region title
      ctx.fillStyle = "#1e293b"
      ctx.font = "bold 14px sans-serif"
      ctx.textAlign = "center"
      ctx.textBaseline = "bottom"
      ctx.fillText("Regions", regionLeft + regionWidth / 2, chartTop - 10)

      // Draw regions
      demographicFlowData.regions.forEach((region, index) => {
        const y = chartTop + index * regionSpacing + regionHeight / 2

        // Draw region box
        ctx.fillStyle = `rgba(213, 94, 0, ${0.5 + region.value / 100})`
        ctx.fillRect(regionLeft, y - regionHeight / 2, regionWidth, regionHeight)

        // Draw region label
        ctx.fillStyle = "#ffffff"
        ctx.font = "bold 12px sans-serif"
        ctx.textAlign = "center"
        ctx.textBaseline = "middle"
        ctx.fillText(region.name, regionLeft + regionWidth / 2, y)

        // Draw percentage
        ctx.fillText(`${region.value}%`, regionLeft + regionWidth / 2, y + regionHeight / 4)
      })

      // Draw parties in the middle
      const parties = ["Conservative", "Labour", "Liberal Democrat", "Reform UK", "Green"]
      const partyWidth = 80
      const partyLeft = (ageGroupLeft + ageGroupWidth + regionLeft) / 2 - partyWidth / 2
      const partySpacing = chartHeight / parties.length
      const partyHeight = partySpacing * 0.7

      // Draw party title
      ctx.fillStyle = "#1e293b"
      ctx.font = "bold 14px sans-serif"
      ctx.textAlign = "center"
      ctx.textBaseline = "bottom"
      ctx.fillText("Parties", partyLeft + partyWidth / 2, chartTop - 10)

      // Draw parties
      parties.forEach((party, index) => {
        const y = chartTop + index * partySpacing + partyHeight / 2
        const color = partyColors[party as keyof typeof partyColors]

        // Draw party box
        ctx.fillStyle = color
        ctx.fillRect(partyLeft, y - partyHeight / 2, partyWidth, partyHeight)

        // Draw party label
        ctx.fillStyle = "#ffffff"
        ctx.font = "bold 12px sans-serif"
        ctx.textAlign = "center"
        ctx.textBaseline = "middle"
        ctx.fillText(party === "Liberal Democrat" ? "Lib Dem" : party, partyLeft + partyWidth / 2, y)
      })

      // Draw connections from age groups to parties
      demographicFlowData.ageGroups.forEach((group, groupIndex) => {
        const groupY = chartTop + groupIndex * ageGroupSpacing + ageGroupHeight / 2

        // Draw connections to each party
        parties.forEach((party, partyIndex) => {
          const partyY = chartTop + partyIndex * partySpacing + partyHeight / 2
          const partyKey = party.toLowerCase().replace(/ /g, "")
          const value = group[partyKey as keyof typeof group] as number

          if (value > 0) {
            // Calculate line width based on value
            const lineWidth = Math.max(1, value / 10)

            // Draw connection line
            ctx.beginPath()
            ctx.moveTo(ageGroupLeft + ageGroupWidth, groupY)
            ctx.bezierCurveTo(ageGroupLeft + ageGroupWidth + 50, groupY, partyLeft - 50, partyY, partyLeft, partyY)
            ctx.strokeStyle = `rgba(100, 116, 139, ${value / 100})`
            ctx.lineWidth = lineWidth
            ctx.stroke()

            // Draw small label with percentage
            const labelX = (ageGroupLeft + ageGroupWidth + partyLeft) / 2
            const labelY = (groupY + partyY) / 2 - 10 * (Math.abs(groupIndex - partyIndex) % 2)
            ctx.fillStyle = "#1e293b"
            ctx.font = "10px sans-serif"
            ctx.textAlign = "center"
            ctx.textBaseline = "middle"
            ctx.fillText(`${value}%`, labelX, labelY)
          }
        })
      })

      // Draw connections from parties to regions
      demographicFlowData.regions.forEach((region, regionIndex) => {
        const regionY = chartTop + regionIndex * regionSpacing + regionHeight / 2

        // Draw connections from each party
        parties.forEach((party, partyIndex) => {
          const partyY = chartTop + partyIndex * partySpacing + partyHeight / 2
          const partyKey = party.toLowerCase().replace(/ /g, "")
          const value = region[partyKey as keyof typeof region] as number

          if (value > 0) {
            // Calculate line width based on value
            const lineWidth = Math.max(1, value / 10)

            // Draw connection line
            ctx.beginPath()
            ctx.moveTo(partyLeft + partyWidth, partyY)
            ctx.bezierCurveTo(partyLeft + partyWidth + 50, partyY, regionLeft - 50, regionY, regionLeft, regionY)
            ctx.strokeStyle = `rgba(100, 116, 139, ${value / 100})`
            ctx.lineWidth = lineWidth
            ctx.stroke()

            // Draw small label with percentage
            const labelX = (partyLeft + partyWidth + regionLeft) / 2
            const labelY = (partyY + regionY) / 2 + 10 * (Math.abs(regionIndex - partyIndex) % 2)
            ctx.fillStyle = "#1e293b"
            ctx.font = "10px sans-serif"
            ctx.textAlign = "center"
            ctx.textBaseline = "middle"
            ctx.fillText(`${value}%`, labelX, labelY)
          }
        })
      })

      // Draw legend for the 219 bubble insights
      const legendX = 50
      const legendY = chartBottom + 10
      const legendWidth = parentWidth - 100
      const legendHeight = 40

      // Legend background
      ctx.fillStyle = "rgba(241, 245, 249, 0.8)"
      ctx.fillRect(legendX, legendY, legendWidth, legendHeight)
      ctx.strokeStyle = "#e2e8f0"
      ctx.lineWidth = 1
      ctx.strokeRect(legendX, legendY, legendWidth, legendHeight)

      // Legend title
      ctx.fillStyle = "#1e293b"
      ctx.font = "bold 12px sans-serif"
      ctx.textAlign = "left"
      ctx.textBaseline = "top"
      ctx.fillText("219 Bubble Insights:", legendX + 10, legendY + 5)

      // Legend content
      ctx.fillStyle = "#64748b"
      ctx.font = "11px sans-serif"
      ctx.fillText(
        "Each borough contains at least 219 data points showing age, region, and voting patterns.",
        legendX + 10,
        legendY + 22,
      )
    }
  }

  // Draw charts when component mounts or when selections change
  useEffect(() => {
    if (selectedTab === "elections") {
      drawBarChart()
    } else {
      drawFlowChart()
    }

    const handleResize = () => {
      if (selectedTab === "elections") {
        drawBarChart()
      } else {
        drawFlowChart()
      }
    }

    window.addEventListener("resize", handleResize)
    return () => {
      window.removeEventListener("resize", handleResize)
    }
  }, [selectedYear, selectedView, selectedTab, isMobile])

  // Handle year selection
  const handleYearSelect = (year: number) => {
    setSelectedYear(year)
    toast({
      title: `${year} General Election`,
      description: `Showing ${selectedView === "votes" ? "vote share" : "seats won"} for the ${year} UK General Election`,
    })
  }

  // Handle view toggle
  const handleViewToggle = (view: "votes" | "seats") => {
    setSelectedView(view)
  }

  return (
    <div className="w-full h-full flex flex-col">
      <Tabs
        defaultValue="elections"
        value={selectedTab}
        onValueChange={(value) => setSelectedTab(value as "elections" | "flow")}
        className="w-full"
      >
        <div className="flex justify-between items-center mb-2">
          <TabsList className="h-9">
            <TabsTrigger value="elections" className="flex items-center gap-1 text-xs px-2 py-1 h-7">
              <BarChartIcon className="h-3 w-3" />
              {isMobile ? "Elections" : "Election Results"}
            </TabsTrigger>
            <TabsTrigger value="flow" className="flex items-center gap-1 text-xs px-2 py-1 h-7">
              <PieChart className="h-3 w-3" />
              {isMobile ? "Age Data" : "Age Demographics"}
            </TabsTrigger>
          </TabsList>

          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="sm" className="h-7 w-7 p-0">
                  <Info className="h-3 w-3" />
                  <span className="sr-only">Info</span>
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p className="max-w-xs text-xs">
                  {selectedTab === "elections"
                    ? "This chart shows general election results. Toggle between vote share and seats won."
                    : "This chart shows how age demographics influenced voting patterns in the May 2024 election."}
                </p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>

        <TabsContent value="elections" className="mt-0">
          <div className="flex flex-wrap gap-1 mb-2">
            <div className="flex items-center gap-1 mr-2">
              <span className="text-xs font-medium">Election:</span>
              {filteredElectionData.map((election) => (
                <Button
                  key={election.year}
                  variant={selectedYear === election.year ? "default" : "outline"}
                  size="sm"
                  className="h-7 text-xs px-2 py-1"
                  onClick={() => handleYearSelect(election.year)}
                >
                  {election.year}
                </Button>
              ))}
            </div>

            <div className="flex items-center gap-1">
              <span className="text-xs font-medium">View:</span>
              <Button
                variant={selectedView === "votes" ? "default" : "outline"}
                size="sm"
                className="h-7 text-xs px-2 py-1"
                onClick={() => handleViewToggle("votes")}
              >
                Votes
              </Button>
              <Button
                variant={selectedView === "seats" ? "default" : "outline"}
                size="sm"
                className="h-7 text-xs px-2 py-1"
                onClick={() => handleViewToggle("seats")}
              >
                Seats
              </Button>
            </div>
          </div>

          <div className="relative w-full h-[300px] border rounded-md bg-white">
            <canvas ref={barChartRef} className="w-full h-full" />
          </div>

          <Card className="mt-2">
            <CardHeader className="py-1">
              <CardTitle className="text-xs">Key Insights</CardTitle>
            </CardHeader>
            <CardContent className="py-1">
              <ul className="text-xs space-y-1">
                {selectedYear === 2024 ? (
                  <>
                    <li className="flex items-start gap-1">
                      <ArrowRight className="h-3 w-3 mt-0.5 text-primary" />
                      <span>Labour won a historic majority with 412 seats despite only 33.7% of the vote</span>
                    </li>
                    <li className="flex items-start gap-1">
                      <ArrowRight className="h-3 w-3 mt-0.5 text-primary" />
                      <span>Reform UK secured 14.3% of votes but only 4 seats due to FPTP system</span>
                    </li>
                  </>
                ) : selectedYear === 2019 ? (
                  <>
                    <li className="flex items-start gap-1">
                      <ArrowRight className="h-3 w-3 mt-0.5 text-primary" />
                      <span>Conservatives won an 80-seat majority with their "Get Brexit Done" campaign</span>
                    </li>
                    <li className="flex items-start gap-1">
                      <ArrowRight className="h-3 w-3 mt-0.5 text-primary" />
                      <span>Labour lost many traditional seats in the "Red Wall" of northern England</span>
                    </li>
                  </>
                ) : (
                  <>
                    <li className="flex items-start gap-1">
                      <ArrowRight className="h-3 w-3 mt-0.5 text-primary" />
                      <span>Theresa May lost her majority despite starting with a 20-point poll lead</span>
                    </li>
                    <li className="flex items-start gap-1">
                      <ArrowRight className="h-3 w-3 mt-0.5 text-primary" />
                      <span>Labour under Jeremy Corbyn gained 30 seats with a youth-focused campaign</span>
                    </li>
                  </>
                )}
              </ul>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="flow" className="mt-0">
          <div className="relative w-full h-[300px] border rounded-md bg-white">
            <canvas ref={flowChartRef} className="w-full h-full" />
          </div>

          <Card className="mt-2">
            <CardHeader className="py-1">
              <CardTitle className="text-xs">Demographic Insights</CardTitle>
            </CardHeader>
            <CardContent className="py-1">
              <ul className="text-xs space-y-1">
                <li className="flex items-start gap-1">
                  <ArrowRight className="h-3 w-3 mt-0.5 text-primary" />
                  <span>Younger voters (18-29) strongly favored Labour (55%) over Conservatives (15%)</span>
                </li>
                <li className="flex items-start gap-1">
                  <ArrowRight className="h-3 w-3 mt-0.5 text-primary" />
                  <span>Reform UK performed best among 45+ voters, particularly in the North East</span>
                </li>
                <li className="flex items-start gap-1">
                  <ArrowRight className="h-3 w-3 mt-0.5 text-primary" />
                  <span>Each borough's 219+ data points reveal clear demographic voting patterns</span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
