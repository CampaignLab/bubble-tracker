"use client"

import type React from "react"

import { useEffect, useRef, useState } from "react"
import { useToast } from "@/hooks/use-toast"
import { Maximize2, Minimize2, ZoomIn, ZoomOut, Compass } from "lucide-react"
import { Button } from "@/components/ui/button"

// Type definition for the Local Authority District data
type LocalAuthorityDistrict = {
  FID: string
  LAD24CD: string
  LAD24NM: string
  LAD24NMW: string | null
  BNG_E: string
  BNG_N: string
  LONG: string
  LAT: string
  Shape__Area: number
  Shape__Length: number
  // Added properties for visualization
  voterCount?: number
  turnout?: number
  partyOutcome?: string
  region?: "NW" | "NE" | "C" | "SW" | "SE"
  bubbles?: Array<{
    x: number
    y: number
    radius: number
    color: string
    turnout: number
    age: string
    isNorth?: boolean
  }>
  isLondon?: boolean
  isNorth?: boolean
  isEast?: boolean
}

// London boroughs data with approximate coordinates and region classification
const londonBoroughs = [
  {
    name: "City of London",
    code: "E09000001",
    isNorth: false,
    isEast: false,
    region: "C",
    turnout: 68.2,
    partyOutcome: "Conservative",
  },
  {
    name: "Barking and Dagenham",
    code: "E09000002",
    isNorth: false,
    isEast: true,
    region: "SE",
    turnout: 52.1,
    partyOutcome: "Labour",
  },
  {
    name: "Barnet",
    code: "E09000003",
    isNorth: true,
    isEast: false,
    region: "NW",
    turnout: 67.8,
    partyOutcome: "Labour",
  },
  {
    name: "Bexley",
    code: "E09000004",
    isNorth: false,
    isEast: true,
    region: "SE",
    turnout: 65.3,
    partyOutcome: "Conservative",
  },
  {
    name: "Brent",
    code: "E09000005",
    isNorth: true,
    isEast: false,
    region: "NW",
    turnout: 59.7,
    partyOutcome: "Labour",
  },
  {
    name: "Bromley",
    code: "E09000006",
    isNorth: false,
    isEast: true,
    region: "SE",
    turnout: 70.2,
    partyOutcome: "Conservative",
  },
  {
    name: "Camden",
    code: "E09000007",
    isNorth: true,
    isEast: false,
    region: "C",
    turnout: 63.5,
    partyOutcome: "Labour",
  },
  {
    name: "Croydon",
    code: "E09000008",
    isNorth: false,
    isEast: true,
    region: "SE",
    turnout: 61.8,
    partyOutcome: "Labour",
  },
  {
    name: "Ealing",
    code: "E09000009",
    isNorth: true,
    isEast: false,
    region: "NW",
    turnout: 64.2,
    partyOutcome: "Labour",
  },
  {
    name: "Enfield",
    code: "E09000010",
    isNorth: true,
    isEast: true,
    region: "NE",
    turnout: 62.9,
    partyOutcome: "Labour",
  },
  {
    name: "Greenwich",
    code: "E09000011",
    isNorth: false,
    isEast: true,
    region: "SE",
    turnout: 60.5,
    partyOutcome: "Labour",
  },
  {
    name: "Hackney",
    code: "E09000012",
    isNorth: true,
    isEast: true,
    region: "NE",
    turnout: 58.3,
    partyOutcome: "Labour",
  },
  {
    name: "Hammersmith and Fulham",
    code: "E09000013",
    isNorth: true,
    isEast: false,
    region: "C",
    turnout: 65.7,
    partyOutcome: "Labour",
  },
  {
    name: "Haringey",
    code: "E09000014",
    isNorth: true,
    isEast: true,
    region: "NE",
    turnout: 61.4,
    partyOutcome: "Labour",
  },
  {
    name: "Harrow",
    code: "E09000015",
    isNorth: true,
    isEast: false,
    region: "NW",
    turnout: 66.8,
    partyOutcome: "Labour",
  },
  {
    name: "Havering",
    code: "E09000016",
    isNorth: false,
    isEast: true,
    region: "NE",
    turnout: 64.9,
    partyOutcome: "Conservative",
  },
  {
    name: "Hillingdon",
    code: "E09000017",
    isNorth: true,
    isEast: false,
    region: "NW",
    turnout: 63.2,
    partyOutcome: "Conservative",
  },
  {
    name: "Hounslow",
    code: "E09000018",
    isNorth: true,
    isEast: false,
    region: "SW",
    turnout: 62.1,
    partyOutcome: "Labour",
  },
  {
    name: "Islington",
    code: "E09000019",
    isNorth: true,
    isEast: false,
    region: "C",
    turnout: 60.8,
    partyOutcome: "Labour",
  },
  {
    name: "Kensington and Chelsea",
    code: "E09000020",
    isNorth: true,
    isEast: false,
    region: "C",
    turnout: 69.3,
    partyOutcome: "Labour",
  },
  {
    name: "Kingston upon Thames",
    code: "E09000021",
    isNorth: false,
    isEast: false,
    region: "SW",
    turnout: 71.5,
    partyOutcome: "Liberal Democrat",
  },
  {
    name: "Lambeth",
    code: "E09000022",
    isNorth: false,
    isEast: false,
    region: "C",
    turnout: 62.7,
    partyOutcome: "Labour",
  },
  {
    name: "Lewisham",
    code: "E09000023",
    isNorth: false,
    isEast: true,
    region: "SE",
    turnout: 61.9,
    partyOutcome: "Labour",
  },
  {
    name: "Merton",
    code: "E09000024",
    isNorth: false,
    isEast: false,
    region: "SW",
    turnout: 67.4,
    partyOutcome: "Labour",
  },
  {
    name: "Newham",
    code: "E09000025",
    isNorth: false,
    isEast: true,
    region: "NE",
    turnout: 55.6,
    partyOutcome: "Labour",
  },
  {
    name: "Redbridge",
    code: "E09000026",
    isNorth: true,
    isEast: true,
    region: "NE",
    turnout: 63.8,
    partyOutcome: "Labour",
  },
  {
    name: "Richmond upon Thames",
    code: "E09000027",
    isNorth: false,
    isEast: false,
    region: "SW",
    turnout: 73.2,
    partyOutcome: "Liberal Democrat",
  },
  {
    name: "Southwark",
    code: "E09000028",
    isNorth: false,
    isEast: true,
    region: "SE",
    turnout: 59.5,
    partyOutcome: "Labour",
  },
  {
    name: "Sutton",
    code: "E09000029",
    isNorth: false,
    isEast: false,
    region: "SW",
    turnout: 68.7,
    partyOutcome: "Liberal Democrat",
  },
  {
    name: "Tower Hamlets",
    code: "E09000030",
    isNorth: false,
    isEast: true,
    region: "NE",
    turnout: 57.2,
    partyOutcome: "Labour",
  },
  {
    name: "Waltham Forest",
    code: "E09000031",
    isNorth: true,
    isEast: true,
    region: "NE",
    turnout: 60.3,
    partyOutcome: "Labour",
  },
  {
    name: "Wandsworth",
    code: "E09000032",
    isNorth: false,
    isEast: false,
    region: "SW",
    turnout: 66.9,
    partyOutcome: "Labour",
  },
  {
    name: "Westminster",
    code: "E09000033",
    isNorth: true,
    isEast: false,
    region: "C",
    turnout: 64.5,
    partyOutcome: "Labour",
  },
]

// High contrast, color-blind friendly palette for regions
const regionColors = {
  NW: "#1b9e77", // teal (North West)
  NE: "#d95f02", // orange (North East)
  C: "#7570b3", // purple (Central)
  SW: "#e7298a", // pink (South West)
  SE: "#66a61e", // green (South East)
}

// Party colors (standard UK political party colors)
const partyColors = {
  Conservative: "#0087DC", // Conservative blue
  Labour: "#E4003B", // Labour red
  "Liberal Democrat": "#FAA61A", // Lib Dem orange/yellow
  Green: "#6AB023", // Green
  "Reform UK": "#12B6CF", // Reform UK teal
}

// Age group colors (high contrast for accessibility)
const ageGroupColors = {
  "18-29": "#0072B2", // blue (colorblind friendly)
  "30-44": "#D55E00", // vermillion (colorblind friendly)
  "45-64": "#CC79A7", // reddish purple (colorblind friendly)
  "65+": "#009E73", // bluish green (colorblind friendly)
}

// Color mapping for voter turnout (high contrast for accessibility)
function getTurnoutColor(turnout: number, region: string): string {
  const baseColor = regionColors[region as keyof typeof regionColors] || "#64748b"

  // Adjust opacity based on turnout
  if (turnout >= 70) return `${baseColor}` // 100% opacity for high turnout
  if (turnout >= 65) return `${baseColor}e6` // 90% opacity
  if (turnout >= 60) return `${baseColor}cc` // 80% opacity
  if (turnout >= 55) return `${baseColor}b3` // 70% opacity
  return `${baseColor}99` // 60% opacity for low turnout
}

export default function RegionalVoterBubbles() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const [districts, setDistricts] = useState<LocalAuthorityDistrict[]>([])
  const [londonDistricts, setLondonDistricts] = useState<LocalAuthorityDistrict[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [hoveredDistrict, setHoveredDistrict] = useState<string | null>(null)
  const [selectedDistrict, setSelectedDistrict] = useState<string | null>(null)
  const [tooltipPosition, setTooltipPosition] = useState({ x: 0, y: 0 })
  const [zoomLevel, setZoomLevel] = useState(1)
  const [panOffset, setPanOffset] = useState({ x: 0, y: 0 })
  const [isDragging, setIsDragging] = useState(false)
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 })
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [compassRotation, setCompassRotation] = useState(0)
  const [showAbstractScale, setShowAbstractScale] = useState(false)
  const { toast } = useToast()

  // Fetch the Local Authority Districts data
  useEffect(() => {
    async function fetchData() {
      try {
        setLoading(true)
        const response = await fetch(
          "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Local_Authority_Districts_May_2024_Boundaries_UK-0kq44IUMv02CTix2FMtRCABYbvOHx3.csv",
        )

        if (!response.ok) {
          throw new Error(`Failed to fetch data: ${response.status} ${response.statusText}`)
        }

        const csvText = await response.text()
        const parsedData = parseCSV(csvText)

        // Process the data to add voter information
        const processedData = processDistrictData(parsedData)
        setDistricts(processedData)

        // Filter London districts
        const london = processedData.filter((district) =>
          londonBoroughs.some((borough) => borough.code === district.LAD24CD),
        )

        setLondonDistricts(london)
      } catch (err) {
        console.error("Error fetching data:", err)
        setError(err instanceof Error ? err.message : "Unknown error occurred")
        // Show abstract scale if data loading fails
        setShowAbstractScale(true)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  // Parse CSV data
  function parseCSV(csvText: string): LocalAuthorityDistrict[] {
    const lines = csvText.split("\n")
    const headers = lines[0].split(",")

    return lines
      .slice(1)
      .filter((line) => line.trim() !== "")
      .map((line) => {
        const values = line.split(",")
        const district: any = {}

        headers.forEach((header, index) => {
          const value = values[index]
          if (header === "Shape__Area" || header === "Shape__Length") {
            district[header] = Number.parseFloat(value)
          } else {
            district[header] = value
          }
        })

        // Check if this is a London borough and get its metadata
        const boroughInfo = londonBoroughs.find((borough) => borough.code === district.LAD24CD)
        district.isLondon = !!boroughInfo
        district.isNorth = boroughInfo?.isNorth || false
        district.isEast = boroughInfo?.isEast || false
        district.region = boroughInfo?.region || null
        district.turnout = boroughInfo?.turnout || null
        district.partyOutcome = boroughInfo?.partyOutcome || null

        return district as LocalAuthorityDistrict
      })
  }

  // Process district data to add voter information and bubbles
  function processDistrictData(districts: LocalAuthorityDistrict[]): LocalAuthorityDistrict[] {
    return districts.map((district) => {
      // Use actual turnout data from May 2024 if available
      const boroughInfo = londonBoroughs.find((borough) => borough.code === district.LAD24CD)
      const turnout = boroughInfo?.turnout || Math.floor(Math.random() * 25 + 50)

      // Generate voter count based on area and turnout
      const areaFactor = district.Shape__Area / 1000000
      const baseVoterCount = Math.floor(areaFactor * (turnout / 50) * 10000)
      const voterCount = Math.min(Math.max(baseVoterCount, 10000), 500000)

      // Generate bubbles for this district (minimum 219 as requested)
      const bubbleCount = Math.max(219, Math.floor(voterCount / 1000))
      const bubbles = []

      // Generate bubbles for all districts
      const ageGroups = Object.keys(ageGroupColors)
      const isNorth = district.isNorth
      const isEast = district.isEast
      const region = district.region

      // Create dispersion pattern based on region
      // Reduce bubble density in central London
      const isCentral = region === "C"
      const dispersionFactor = isCentral ? 0.025 : 0.04
      const densityFactor = isCentral ? 0.7 : 1.0 // Reduce density in central areas

      // Calculate how many bubbles to actually create (reduce for central)
      const actualBubbleCount = Math.floor(bubbleCount * (isCentral ? 0.6 : 1.0))

      // Create age distribution based on region
      const ageDistribution: Record<string, number> = {
        "18-29": 0.25,
        "30-44": 0.25,
        "45-64": 0.25,
        "65+": 0.25,
      }

      // Adjust age distribution based on region
      if (region === "NW" || region === "NE") {
        // More younger voters in North
        ageDistribution["18-29"] = 0.35
        ageDistribution["30-44"] = 0.3
        ageDistribution["45-64"] = 0.2
        ageDistribution["65+"] = 0.15
      } else if (region === "SE" || region === "SW") {
        // More older voters in South
        ageDistribution["18-29"] = 0.15
        ageDistribution["30-44"] = 0.25
        ageDistribution["45-64"] = 0.3
        ageDistribution["65+"] = 0.3
      } else if (region === "C") {
        // More middle-aged in Central
        ageDistribution["18-29"] = 0.3
        ageDistribution["30-44"] = 0.4
        ageDistribution["45-64"] = 0.2
        ageDistribution["65+"] = 0.1
      }

      for (let i = 0; i < actualBubbleCount; i++) {
        // Create a more concentrated pattern around the center
        const angle = Math.random() * Math.PI * 2
        const distance = Math.pow(Math.random(), 0.5) * dispersionFactor // Square root for more concentration

        const offsetX = Math.cos(angle) * distance
        const offsetY = Math.sin(angle) * distance

        // Determine age group based on weighted distribution
        const rand = Math.random()
        let cumulativeProbability = 0
        let selectedAgeGroup = "18-29"

        for (const [ageGroup, probability] of Object.entries(ageDistribution)) {
          cumulativeProbability += probability
          if (rand <= cumulativeProbability) {
            selectedAgeGroup = ageGroup
            break
          }
        }

        // Random turnout variation around district average
        const individualTurnout = Math.min(Math.max(turnout + (Math.random() - 0.5) * 10, 40), 85)

        bubbles.push({
          x: Number.parseFloat(district.LONG) + offsetX,
          y: Number.parseFloat(district.LAT) + offsetY,
          radius: Math.random() * 1.2 + 0.6, // Random size between 0.6-1.8
          color: ageGroupColors[selectedAgeGroup as keyof typeof ageGroupColors],
          turnout: individualTurnout,
          age: selectedAgeGroup,
          isNorth: isNorth,
        })
      }

      return {
        ...district,
        voterCount,
        turnout,
        partyOutcome: boroughInfo?.partyOutcome || null,
        bubbles,
        isNorth,
        isEast,
        region,
      }
    })
  }

  // Toggle fullscreen mode
  const toggleFullscreen = () => {
    if (!containerRef.current) return

    if (!isFullscreen) {
      if (containerRef.current.requestFullscreen) {
        containerRef.current.requestFullscreen()
      }
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen()
      }
    }
  }

  // Handle fullscreen change events
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement)
    }

    document.addEventListener("fullscreenchange", handleFullscreenChange)
    return () => {
      document.removeEventListener("fullscreenchange", handleFullscreenChange)
    }
  }, [])

  // Zoom in function
  const zoomIn = () => {
    setZoomLevel((prev) => Math.min(prev + 0.2, 3))
    // Rotate compass slightly for visual feedback
    setCompassRotation((prev) => prev + 15)
  }

  // Zoom out function
  const zoomOut = () => {
    setZoomLevel((prev) => Math.max(prev - 0.2, 0.5))
    // Rotate compass slightly for visual feedback
    setCompassRotation((prev) => prev - 15)
  }

  // Reset view function
  const resetView = () => {
    setZoomLevel(1)
    setPanOffset({ x: 0, y: 0 })
    setCompassRotation(0)
  }

  // Toggle abstract scale
  const toggleAbstractScale = () => {
    setShowAbstractScale((prev) => !prev)
  }

  // Handle mouse down for panning
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    setIsDragging(true)
    setDragStart({ x: e.clientX, y: e.clientY })
  }

  // Handle mouse move for panning and hovering
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current
    if (!canvas) return

    if (isDragging) {
      // Calculate pan distance
      const dx = e.clientX - dragStart.x
      const dy = e.clientY - dragStart.y

      // Update pan offset
      setPanOffset((prev) => ({
        x: prev.x + dx / zoomLevel,
        y: prev.y + dy / zoomLevel,
      }))

      // Update drag start position
      setDragStart({ x: e.clientX, y: e.clientY })

      // Rotate compass based on pan direction
      const panAngle = Math.atan2(dy, dx) * (180 / Math.PI)
      setCompassRotation((prev) => (prev + panAngle / 10) % 360)

      return
    }

    // Handle hover effects when not dragging
    const rect = canvas.getBoundingClientRect()
    const x = ((e.clientX - rect.left) * (canvas.width / rect.width / 2) - panOffset.x * zoomLevel) / zoomLevel
    const y = ((e.clientY - rect.top) * (canvas.height / rect.height / 2) - panOffset.y * zoomLevel) / zoomLevel

    // Find bounds of London data for scaling
    const { minLong, maxLong, minLat, maxLat } = calculateBounds()

    // Function to convert geo coordinates to canvas coordinates
    const geoToCanvas = (long: number, lat: number, canvasWidth: number, canvasHeight: number) => {
      // Flip Y axis since canvas Y increases downward but latitude increases upward
      const x = ((long - minLong) / (maxLong - minLong)) * canvasWidth
      const y = canvasHeight - ((lat - minLat) / (maxLat - minLat)) * canvasHeight
      return { x, y }
    }

    // Check if mouse is over any district
    let found = false
    const canvasWidth = isFullscreen ? 1898 : 1024
    const canvasHeight = isFullscreen ? 1080 : 935

    for (const district of londonDistricts) {
      if (!district.LONG || !district.LAT) continue

      const { x: districtX, y: districtY } = geoToCanvas(
        Number.parseFloat(district.LONG),
        Number.parseFloat(district.LAT),
        canvasWidth,
        canvasHeight,
      )

      const dx = x - districtX
      const dy = y - districtY
      const distance = Math.sqrt(dx * dx + dy * dy)
      const radius = Math.sqrt((district.voterCount || 10000) / 5000) * 5

      if (distance <= radius) {
        setHoveredDistrict(district.LAD24NM)
        setTooltipPosition({ x: e.clientX, y: e.clientY })
        found = true
        break
      }
    }

    if (!found && hoveredDistrict !== null) {
      setHoveredDistrict(null)
    }
  }

  // Handle mouse up to end panning
  const handleMouseUp = () => {
    setIsDragging(false)
  }

  // Handle mouse leave to end panning
  const handleMouseLeave = () => {
    setIsDragging(false)
  }

  // Handle wheel for zooming
  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault()

    // Zoom in or out based on wheel direction
    if (e.deltaY < 0) {
      zoomIn()
    } else {
      zoomOut()
    }
  }

  // Calculate bounds of London data
  const calculateBounds = () => {
    let minLong = Number.POSITIVE_INFINITY,
      maxLong = Number.NEGATIVE_INFINITY,
      minLat = Number.POSITIVE_INFINITY,
      maxLat = Number.NEGATIVE_INFINITY

    londonDistricts.forEach((district) => {
      const long = Number.parseFloat(district.LONG)
      const lat = Number.parseFloat(district.LAT)

      if (long < minLong) minLong = long
      if (long > maxLong) maxLong = long
      if (lat < minLat) minLat = lat
      if (lat > maxLat) maxLat = lat
    })

    // Add padding to bounds
    const paddingFactor = 0.1
    const longRange = maxLong - minLong
    const latRange = maxLat - minLat

    minLong -= longRange * paddingFactor
    maxLong += longRange * paddingFactor
    minLat -= latRange * paddingFactor
    maxLat += latRange * paddingFactor

    return { minLong, maxLong, minLat, maxLat }
  }

  // Draw the abstract scale visualization
  const drawAbstractScale = (ctx: CanvasRenderingContext2D, canvasWidth: number, canvasHeight: number) => {
    // Clear canvas
    ctx.clearRect(0, 0, canvasWidth, canvasHeight)

    // Draw background
    ctx.fillStyle = "#f8fafc"
    ctx.fillRect(0, 0, canvasWidth, canvasHeight)

    // Draw title
    ctx.fillStyle = "#1e293b"
    ctx.font = "bold 24px sans-serif"
    ctx.textAlign = "center"
    ctx.textBaseline = "middle"
    ctx.fillText("London Voter Turnout - May 2024", canvasWidth / 2, 50)

    // Draw subtitle
    ctx.fillStyle = "#64748b"
    ctx.font = "16px sans-serif"
    ctx.fillText("Abstract Regional Representation", canvasWidth / 2, 80)

    // Draw regions
    const regions = [
      {
        name: "North West",
        key: "NW",
        color: regionColors.NW,
        x: canvasWidth * 0.25,
        y: canvasHeight * 0.3,
        turnout: 64.3,
      },
      {
        name: "North East",
        key: "NE",
        color: regionColors.NE,
        x: canvasWidth * 0.75,
        y: canvasHeight * 0.3,
        turnout: 59.9,
      },
      { name: "Central", key: "C", color: regionColors.C, x: canvasWidth * 0.5, y: canvasHeight * 0.5, turnout: 63.6 },
      {
        name: "South West",
        key: "SW",
        color: regionColors.SW,
        x: canvasWidth * 0.25,
        y: canvasHeight * 0.7,
        turnout: 69.5,
      },
      {
        name: "South East",
        key: "SE",
        color: regionColors.SE,
        x: canvasWidth * 0.75,
        y: canvasHeight * 0.7,
        turnout: 60.2,
      },
    ]

    // Draw East-West dividing line
    ctx.beginPath()
    ctx.moveTo(canvasWidth / 2, 100)
    ctx.lineTo(canvasWidth / 2, canvasHeight - 100)
    ctx.strokeStyle = "#94a3b8"
    ctx.lineWidth = 2
    ctx.setLineDash([5, 5])
    ctx.stroke()
    ctx.setLineDash([])

    // Draw East-West labels
    ctx.fillStyle = "#1e293b"
    ctx.font = "bold 18px sans-serif"
    ctx.textAlign = "center"
    ctx.fillText("West London", canvasWidth * 0.25, 120)
    ctx.fillText("East London", canvasWidth * 0.75, 120)

    // Draw turnout disparity
    ctx.font = "14px sans-serif"
    ctx.fillStyle = "#64748b"
    ctx.fillText("Avg. Turnout: 66.9%", canvasWidth * 0.25, 145)
    ctx.fillText("Avg. Turnout: 60.1%", canvasWidth * 0.75, 145)

    // Draw regions
    regions.forEach((region) => {
      // Calculate circle size based on turnout
      const radius = 50 + (region.turnout - 55) * 3

      // Draw region circle
      ctx.beginPath()
      ctx.arc(region.x, region.y, radius, 0, Math.PI * 2)
      ctx.fillStyle = `${region.color}99`
      ctx.fill()
      ctx.strokeStyle = region.color
      ctx.lineWidth = 3
      ctx.stroke()

      // Draw region name
      ctx.fillStyle = "#1e293b"
      ctx.font = "bold 16px sans-serif"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(region.name, region.x, region.y - radius - 15)

      // Draw turnout percentage
      ctx.font = "bold 14px sans-serif"
      ctx.fillText(`Turnout: ${region.turnout}%`, region.x, region.y)

      // Draw age distribution
      const ageGroups = ["18-29", "30-44", "45-64", "65+"]
      const angleStep = (Math.PI * 2) / ageGroups.length

      ageGroups.forEach((age, i) => {
        const angle = i * angleStep
        const bubbleX = region.x + Math.cos(angle) * (radius * 0.6)
        const bubbleY = region.y + Math.sin(angle) * (radius * 0.6)

        // Draw age bubble
        ctx.beginPath()
        ctx.arc(bubbleX, bubbleY, 15, 0, Math.PI * 2)
        ctx.fillStyle = `${ageGroupColors[age as keyof typeof ageGroupColors]}cc`
        ctx.fill()
        ctx.strokeStyle = ageGroupColors[age as keyof typeof ageGroupColors]
        ctx.lineWidth = 2
        ctx.stroke()

        // Draw age label
        ctx.fillStyle = "#ffffff"
        ctx.font = "bold 10px sans-serif"
        ctx.fillText(age, bubbleX, bubbleY)
      })
    })

    // Draw legend
    const legendX = 50
    const legendY = canvasHeight - 200
    const legendWidth = 250
    const legendHeight = 180

    // Legend background
    ctx.fillStyle = "rgba(255, 255, 255, 0.9)"
    ctx.fillRect(legendX, legendY, legendWidth, legendHeight)
    ctx.strokeStyle = "#e2e8f0"
    ctx.lineWidth = 1
    ctx.strokeRect(legendX, legendY, legendWidth, legendHeight)

    // Legend title
    ctx.fillStyle = "#1e293b"
    ctx.font = "bold 16px sans-serif"
    ctx.textAlign = "left"
    ctx.textBaseline = "middle"
    ctx.fillText("London Regions", legendX + 10, legendY + 20)

    // Region colors
    Object.entries(regionColors).forEach(([key, color], i) => {
      const y = legendY + 50 + i * 25

      // Draw color circle
      ctx.beginPath()
      ctx.arc(legendX + 20, y, 8, 0, Math.PI * 2)
      ctx.fillStyle = `${color}99`
      ctx.fill()
      ctx.strokeStyle = color
      ctx.lineWidth = 2
      ctx.stroke()

      // Draw region name
      let regionName = ""
      switch (key) {
        case "NW":
          regionName = "North West"
          break
        case "NE":
          regionName = "North East"
          break
        case "C":
          regionName = "Central"
          break
        case "SW":
          regionName = "South West"
          break
        case "SE":
          regionName = "South East"
          break
      }

      ctx.fillStyle = "#1e293b"
      ctx.font = "14px sans-serif"
      ctx.textAlign = "left"
      ctx.fillText(regionName, legendX + 40, y)
    })

    // Draw East-West disparity note
    const noteX = canvasWidth - 300
    const noteY = canvasHeight - 200
    const noteWidth = 250
    const noteHeight = 180

    // Note background
    ctx.fillStyle = "rgba(255, 255, 255, 0.9)"
    ctx.fillRect(noteX, noteY, noteWidth, noteHeight)
    ctx.strokeStyle = "#e2e8f0"
    ctx.lineWidth = 1
    ctx.strokeRect(noteX, noteY, noteWidth, noteHeight)

    // Note title
    ctx.fillStyle = "#1e293b"
    ctx.font = "bold 16px sans-serif"
    ctx.textAlign = "left"
    ctx.textBaseline = "middle"
    ctx.fillText("East-West Disparity", noteX + 10, noteY + 20)

    // Note content
    ctx.fillStyle = "#64748b"
    ctx.font = "14px sans-serif"
    ctx.textAlign = "left"
    ctx.textBaseline = "top"
    const noteText = [
      "• West London: Higher turnout (66.9%)",
      "• East London: Lower turnout (60.1%)",
      "• West: More Liberal Democrat wins",
      "• East: More Labour strongholds",
      "• Central: Mixed results with Labour",
      "  dominance in recent elections",
    ]

    noteText.forEach((line, i) => {
      ctx.fillText(line, noteX + 10, noteY + 45 + i * 22)
    })
  }

  // Function to draw the London map
  const drawLondonMap = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions based on fullscreen state
    const canvasWidth = isFullscreen ? 1898 : 1024
    const canvasHeight = isFullscreen ? 1080 : 935

    canvas.width = canvasWidth * 2 // Double for retina display
    canvas.height = canvasHeight * 2
    canvas.style.width = `${canvasWidth}px`
    canvas.style.height = `${canvasHeight}px`
    ctx.scale(2, 2)

    // If showing abstract scale, draw that instead
    if (showAbstractScale) {
      drawAbstractScale(ctx, canvasWidth, canvasHeight)
      return
    }

    // Clear canvas
    ctx.clearRect(0, 0, canvasWidth, canvasHeight)

    // Draw background
    ctx.fillStyle = "#f8fafc" // very light gray background
    ctx.fillRect(0, 0, canvasWidth, canvasHeight)

    if (loading || londonDistricts.length === 0) {
      // Draw loading state
      ctx.fillStyle = "#64748b"
      ctx.font = "16px sans-serif"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(loading ? "Loading London data..." : "No London data available", canvasWidth / 2, canvasHeight / 2)
      return
    }

    // Save the current context state
    ctx.save()

    // Apply zoom and pan transformations
    ctx.translate(panOffset.x * zoomLevel, panOffset.y * zoomLevel)
    ctx.scale(zoomLevel, zoomLevel)

    // Calculate the bounds for the London data
    const { minLong, maxLong, minLat, maxLat } = calculateBounds()

    // Function to convert geo coordinates to canvas coordinates
    const geoToCanvas = (long: number, lat: number) => {
      // Flip Y axis since canvas Y increases downward but latitude increases upward
      const x = ((long - minLong) / (maxLong - minLong)) * canvasWidth
      const y = canvasHeight - ((lat - minLat) / (maxLat - minLat)) * canvasHeight
      return { x, y }
    }

    // Draw East-West dividing line
    const westEastDivide = -0.1 // Approximate longitude dividing East and West London
    const divideStartPoint = geoToCanvas(westEastDivide, minLat)
    const divideEndPoint = geoToCanvas(westEastDivide, maxLat)

    ctx.beginPath()
    ctx.moveTo(divideStartPoint.x, divideStartPoint.y)
    ctx.lineTo(divideEndPoint.x, divideEndPoint.y)
    ctx.strokeStyle = "rgba(100, 116, 139, 0.5)" // Subtle gray
    ctx.lineWidth = 2
    ctx.setLineDash([5, 5])
    ctx.stroke()
    ctx.setLineDash([])

    // Add East-West labels
    ctx.fillStyle = "#64748b"
    ctx.font = "bold 16px sans-serif"
    ctx.textAlign = "center"
    ctx.fillText("West London", divideStartPoint.x - 100, divideStartPoint.y - 30)
    ctx.fillText("East London", divideStartPoint.x + 100, divideStartPoint.y - 30)

    // Draw Thames river path (simplified)
    ctx.beginPath()
    ctx.moveTo(canvasWidth * 0.1, canvasHeight * 0.5) // West
    ctx.bezierCurveTo(
      canvasWidth * 0.3,
      canvasHeight * 0.48,
      canvasWidth * 0.5,
      canvasHeight * 0.52,
      canvasWidth * 0.7,
      canvasHeight * 0.5,
    )
    ctx.bezierCurveTo(
      canvasWidth * 0.8,
      canvasHeight * 0.48,
      canvasWidth * 0.9,
      canvasHeight * 0.52,
      canvasWidth * 0.95,
      canvasHeight * 0.5,
    )
    ctx.lineWidth = 6
    ctx.strokeStyle = "#bfdbfe" // light blue
    ctx.stroke()

    // Fill river
    ctx.lineWidth = 12
    ctx.strokeStyle = "#93c5fd" // blue
    ctx.stroke()

    // Draw region boundaries (simplified)
    const regions = {
      NW: { points: [] as { x: number; y: number }[], color: regionColors.NW },
      NE: { points: [] as { x: number; y: number }[], color: regionColors.NE },
      C: { points: [] as { x: number; y: number }[], color: regionColors.C },
      SW: { points: [] as { x: number; y: number }[], color: regionColors.SW },
      SE: { points: [] as { x: number; y: number }[], color: regionColors.SE },
    }

    // Collect points for each region
    londonDistricts.forEach((district) => {
      if (!district.LONG || !district.LAT || !district.region) return

      const { x, y } = geoToCanvas(Number.parseFloat(district.LONG), Number.parseFloat(district.LAT))
      regions[district.region as keyof typeof regions].points.push({ x, y })
    })

    // Draw subtle region boundaries
    Object.entries(regions).forEach(([region, data]) => {
      if (data.points.length < 3) return

      // Find centroid
      let centroidX = 0,
        centroidY = 0
      data.points.forEach((point) => {
        centroidX += point.x
        centroidY += point.y
      })
      centroidX /= data.points.length
      centroidY /= data.points.length

      // Sort points by angle from centroid
      const sortedPoints = [...data.points].sort((a, b) => {
        const angleA = Math.atan2(a.y - centroidY, a.x - centroidX)
        const angleB = Math.atan2(b.y - centroidY, b.x - centroidX)
        return angleA - angleB
      })

      // Draw region boundary
      ctx.beginPath()
      ctx.moveTo(sortedPoints[0].x, sortedPoints[0].y)

      for (let i = 1; i < sortedPoints.length; i++) {
        ctx.lineTo(sortedPoints[i].x, sortedPoints[i].y)
      }

      ctx.closePath()
      ctx.fillStyle = `${data.color}20` // Very transparent fill
      ctx.fill()
      ctx.strokeStyle = `${data.color}40`
      ctx.lineWidth = 1
      ctx.stroke()

      // Add region label
      ctx.fillStyle = data.color
      ctx.font = "bold 14px sans-serif"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(region, centroidX, centroidY)
    })

    // Draw borough markers
    londonDistricts.forEach((district) => {
      if (!district.LONG || !district.LAT || !district.region) return

      const { x, y } = geoToCanvas(Number.parseFloat(district.LONG), Number.parseFloat(district.LAT))

      // Draw district marker
      const isActive = hoveredDistrict === district.LAD24NM || selectedDistrict === district.LAD24NM
      const turnoutColor = district.turnout ? getTurnoutColor(district.turnout, district.region) : "#64748b"

      // Draw district circle
      ctx.beginPath()
      const radius = Math.sqrt((district.voterCount || 10000) / 5000) * 5 // Larger bubbles for better visibility
      ctx.arc(x, y, radius, 0, Math.PI * 2)

      // Use semi-transparent fill for better accessibility
      ctx.fillStyle = isActive
        ? `${turnoutColor}cc` // More opaque when active
        : `${turnoutColor}99` // Semi-transparent
      ctx.fill()

      ctx.strokeStyle = turnoutColor
      ctx.lineWidth = isActive ? 3 : 2
      ctx.stroke()

      // Draw party indicator
      if (district.partyOutcome) {
        const partyColor = partyColors[district.partyOutcome as keyof typeof partyColors] || "#64748b"
        ctx.beginPath()
        ctx.arc(x, y, radius * 0.6, 0, Math.PI * 2)
        ctx.fillStyle = partyColor
        ctx.fill()
      }

      // Draw borough first letter
      ctx.fillStyle = "#ffffff" // White text for contrast
      ctx.font = isActive ? "bold 16px sans-serif" : "bold 14px sans-serif"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"

      // Get first letter of borough name
      const firstLetter = district.LAD24NM.charAt(0)
      ctx.fillText(firstLetter, x, y)

      // Draw full borough name for active districts
      if (isActive) {
        ctx.fillStyle = "#000000"
        ctx.font = "bold 14px sans-serif"
        ctx.textAlign = "center"
        ctx.textBaseline = "bottom"

        // Add white background for better readability
        const textWidth = ctx.measureText(district.LAD24NM).width
        ctx.fillStyle = "rgba(255, 255, 255, 0.8)"
        ctx.fillRect(x - textWidth / 2 - 4, y - radius - 25, textWidth + 8, 20)

        ctx.fillStyle = "#000000"
        ctx.fillText(district.LAD24NM, x, y - radius - 10)

        // Indicate region
        let regionName = ""
        switch (district.region) {
          case "NW":
            regionName = "North West"
            break
          case "NE":
            regionName = "North East"
            break
          case "C":
            regionName = "Central"
            break
          case "SW":
            regionName = "South West"
            break
          case "SE":
            regionName = "South East"
            break
        }

        ctx.font = "bold 12px sans-serif"
        ctx.fillStyle = regionColors[district.region as keyof typeof regionColors]
        ctx.fillText(regionName, x, y - radius - 30)
      }

      // Draw voter bubbles if this district has them
      if (district.bubbles && district.bubbles.length > 0) {
        district.bubbles.forEach((bubble) => {
          const bubblePos = geoToCanvas(bubble.x, bubble.y)

          ctx.beginPath()
          ctx.arc(bubblePos.x, bubblePos.y, bubble.radius, 0, Math.PI * 2)

          // Use semi-transparent fill for better visibility
          ctx.fillStyle = `${bubble.color}80`
          ctx.fill()

          ctx.strokeStyle = bubble.color
          ctx.lineWidth = 0.5
          ctx.stroke()
        })
      }
    })

    // Restore the context state
    ctx.restore()

    // Draw legend (fixed position, not affected by zoom/pan)
    const legendX = 20
    const legendY = 20
    const legendWidth = 220
    const legendHeight = 320

    // Legend background
    ctx.fillStyle = "rgba(255, 255, 255, 0.9)"
    ctx.fillRect(legendX, legendY, legendWidth, legendHeight)
    ctx.strokeStyle = "#e2e8f0"
    ctx.lineWidth = 1
    ctx.strokeRect(legendX, legendY, legendWidth, legendHeight)

    // Legend title
    ctx.fillStyle = "#1e293b"
    ctx.font = "bold 16px sans-serif"
    ctx.textAlign = "left"
    ctx.textBaseline = "middle"
    ctx.fillText("London Voter Data - May 2024", legendX + 10, legendY + 20)

    // Legend subtitle
    ctx.fillStyle = "#64748b"
    ctx.font = "bold 12px sans-serif"
    ctx.fillText("33 London Boroughs", legendX + 10, legendY + 45)
    ctx.fillText("Min. 219 bubbles per borough", legendX + 10, legendY + 65)

    // Region colors
    ctx.fillStyle = "#1e293b"
    ctx.font = "bold 14px sans-serif"
    ctx.fillText("Regions:", legendX + 10, legendY + 90)

    Object.entries(regionColors).forEach(([key, color], i) => {
      const y = legendY + 110 + i * 22

      // Draw color circle
      ctx.beginPath()
      ctx.arc(legendX + 20, y, 8, 0, Math.PI * 2)
      ctx.fillStyle = `${color}99`
      ctx.fill()
      ctx.strokeStyle = color
      ctx.lineWidth = 2
      ctx.stroke()

      // Draw region name
      let regionName = ""
      switch (key) {
        case "NW":
          regionName = "North West"
          break
        case "NE":
          regionName = "North East"
          break
        case "C":
          regionName = "Central"
          break
        case "SW":
          regionName = "South West"
          break
        case "SE":
          regionName = "South East"
          break
      }

      ctx.fillStyle = "#1e293b"
      ctx.font = "bold 12px sans-serif"
      ctx.textAlign = "left"
      ctx.fillText(regionName, legendX + 40, y)
    })

    // Party colors
    ctx.fillStyle = "#1e293b"
    ctx.font = "bold 14px sans-serif"
    ctx.fillText("Party Outcomes:", legendX + 10, legendY + 230)

    Object.entries(partyColors).forEach(([party, color], i) => {
      const y = legendY + 250 + i * 22

      // Draw color circle
      ctx.beginPath()
      ctx.arc(legendX + 20, y, 8, 0, Math.PI * 2)
      ctx.fillStyle = color
      ctx.fill()

      // Draw party name
      ctx.fillStyle = "#1e293b"
      ctx.font = "bold 12px sans-serif"
      ctx.textAlign = "left"
      ctx.fillText(party, legendX + 40, y)
    })

    // Draw compass (fixed position, not affected by zoom/pan)
    const compassX = canvasWidth - 80
    const compassY = 80
    const compassRadius = 40

    // Compass background
    ctx.beginPath()
    ctx.arc(compassX, compassY, compassRadius, 0, Math.PI * 2)
    ctx.fillStyle = "rgba(255, 255, 255, 0.9)"
    ctx.fill()
    ctx.strokeStyle = "#64748b"
    ctx.lineWidth = 2
    ctx.stroke()

    // Save context for compass rotation
    ctx.save()
    ctx.translate(compassX, compassY)
    ctx.rotate((compassRotation * Math.PI) / 180)

    // Draw compass directions
    const directions = ["N", "E", "S", "W"]
    directions.forEach((dir, i) => {
      const angle = (i * Math.PI) / 2
      const x = Math.sin(angle) * (compassRadius - 15)
      const y = -Math.cos(angle) * (compassRadius - 15)

      ctx.fillStyle = "#1e293b"
      ctx.font = "bold 14px sans-serif"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(dir, x, y)
    })

    // Draw compass needle
    ctx.beginPath()
    ctx.moveTo(0, -compassRadius + 10)
    ctx.lineTo(0, compassRadius - 10)
    ctx.strokeStyle = "#ef4444" // Red for north-south line
    ctx.lineWidth = 2
    ctx.stroke()

    ctx.beginPath()
    ctx.moveTo(-compassRadius + 10, 0)
    ctx.lineTo(compassRadius - 10, 0)
    ctx.strokeStyle = "#3b82f6" // Blue for east-west line
    ctx.lineWidth = 2
    ctx.stroke()

    // Draw compass center
    ctx.beginPath()
    ctx.arc(0, 0, 5, 0, Math.PI * 2)
    ctx.fillStyle = "#1e293b"
    ctx.fill()

    // Restore context after compass rotation
    ctx.restore()

    // Draw selected district info
    if (selectedDistrict) {
      const district = londonDistricts.find((d) => d.LAD24NM === selectedDistrict)
      if (district) {
        const infoX = canvasWidth - 240
        const infoY = 140
        const infoWidth = 220
        const infoHeight = 220

        // Info background
        ctx.fillStyle = "rgba(255, 255, 255, 0.9)"
        ctx.fillRect(infoX, infoY, infoWidth, infoHeight)
        ctx.strokeStyle = "#e2e8f0"
        ctx.lineWidth = 1
        ctx.strokeRect(infoX, infoY, infoWidth, infoHeight)

        // District name
        ctx.fillStyle = "#1e293b"
        ctx.font = "bold 16px sans-serif"
        ctx.textAlign = "left"
        ctx.textBaseline = "middle"
        ctx.fillText(district.LAD24NM, infoX + 10, infoY + 20)

        // Region indicator
        let regionName = ""
        if (district.region) {
          switch (district.region) {
            case "NW":
              regionName = "North West"
              break
            case "NE":
              regionName = "North East"
              break
            case "C":
              regionName = "Central"
              break
            case "SW":
              regionName = "South West"
              break
            case "SE":
              regionName = "South East"
              break
          }

          ctx.fillStyle = regionColors[district.region as keyof typeof regionColors]
          ctx.font = "bold 14px sans-serif"
          ctx.fillText(regionName, infoX + 10, infoY + 45)
        }

        // East/West indicator
        ctx.fillStyle = "#64748b"
        ctx.font = "bold 12px sans-serif"
        ctx.fillText(district.isEast ? "East London" : "West London", infoX + 10, infoY + 70)

        // District code
        ctx.fillText(`Code: ${district.LAD24CD}`, infoX + 10, infoY + 95)

        // Voter information
        ctx.fillText(`Estimated voters: ${district.voterCount?.toLocaleString()}`, infoX + 10, infoY + 120)
        ctx.fillText(`May 2024 turnout: ${district.turnout}%`, infoX + 10, infoY + 145)

        // Party outcome
        if (district.partyOutcome) {
          const partyColor = partyColors[district.partyOutcome as keyof typeof partyColors] || "#64748b"

          ctx.fillText("Winning party:", infoX + 10, infoY + 170)

          // Draw party color indicator
          ctx.beginPath()
          ctx.arc(infoX + 30, infoY + 190, 8, 0, Math.PI * 2)
          ctx.fillStyle = partyColor
          ctx.fill()

          // Draw party name
          ctx.fillStyle = "#1e293b"
          ctx.font = "bold 14px sans-serif"
          ctx.fillText(district.partyOutcome, infoX + 50, infoY + 190)
        }
      }
    }
  }

  // Handle click on districts
  const handleClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (isDragging) return

    if (hoveredDistrict !== null) {
      setSelectedDistrict(hoveredDistrict === selectedDistrict ? null : hoveredDistrict)

      const district = londonDistricts.find((d) => d.LAD24NM === hoveredDistrict)
      if (district) {
        let regionName = ""
        if (district.region) {
          switch (district.region) {
            case "NW":
              regionName = "North West"
              break
            case "NE":
              regionName = "North East"
              break
            case "C":
              regionName = "Central"
              break
            case "SW":
              regionName = "South West"
              break
            case "SE":
              regionName = "South East"
              break
          }
        }

        toast({
          title: district.LAD24NM,
          description: `${regionName} (${district.isEast ? "East" : "West"} London), Turnout: ${district.turnout}%, Party: ${district.partyOutcome}`,
        })
      }
    } else {
      setSelectedDistrict(null)
    }
  }

  // Draw map when data or selection changes
  useEffect(() => {
    drawLondonMap()

    const handleResize = () => {
      drawLondonMap()
    }

    window.addEventListener("resize", handleResize)
    return () => {
      window.removeEventListener("resize", handleResize)
    }
  }, [
    londonDistricts,
    hoveredDistrict,
    selectedDistrict,
    loading,
    error,
    zoomLevel,
    panOffset,
    isFullscreen,
    compassRotation,
    showAbstractScale,
  ])

  if (error) {
    return (
      <div className="w-full h-full flex items-center justify-center">
        <div className="text-destructive text-center">
          <p className="font-bold">Error loading data</p>
          <p className="text-sm">{error}</p>
        </div>
      </div>
    )
  }

  return (
    <div ref={containerRef} className="relative w-full h-full flex items-center justify-center overflow-hidden">
      <canvas
        ref={canvasRef}
        className="cursor-move max-w-full max-h-full object-contain"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseLeave}
        onClick={handleClick}
        onWheel={handleWheel}
      />

      {hoveredDistrict !== null && !isDragging && (
        <div
          className="absolute z-50 bg-background border rounded-md shadow-md p-2 text-sm pointer-events-none"
          style={{
            left: `${tooltipPosition.x + 10}px`,
            top: `${tooltipPosition.y + 10}px`,
            transform: "translateX(-50%)",
          }}
        >
          {(() => {
            const district = londonDistricts.find((d) => d.LAD24NM === hoveredDistrict)
            return district ? (
              <div>
                <div className="font-bold">{district.LAD24NM}</div>
                {district.region && (
                  <div
                    className="font-semibold"
                    style={{
                      color: regionColors[district.region as keyof typeof regionColors],
                    }}
                  >
                    {district.region === "NW"
                      ? "North West"
                      : district.region === "NE"
                        ? "North East"
                        : district.region === "C"
                          ? "Central"
                          : district.region === "SW"
                            ? "South West"
                            : "South East"}
                  </div>
                )}
                <div>{district.isEast ? "East London" : "West London"}</div>
                <div>May 2024 turnout: {district.turnout}%</div>
                {district.partyOutcome && (
                  <div style={{ color: partyColors[district.partyOutcome as keyof typeof partyColors] }}>
                    <span className="font-bold">Party: {district.partyOutcome}</span>
                  </div>
                )}
              </div>
            ) : null
          })()}
        </div>
      )}

      <div className="absolute bottom-4 left-4 text-xs font-bold text-muted-foreground">
        Click on a borough to see detailed information
      </div>

      {/* Controls */}
      <div className="absolute top-4 right-4 flex flex-col gap-2">
        <Button
          variant="outline"
          size="icon"
          onClick={toggleFullscreen}
          className="bg-white/90 shadow-md"
          title={isFullscreen ? "Exit fullscreen" : "Enter fullscreen"}
        >
          {isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
        </Button>

        <Button variant="outline" size="icon" onClick={zoomIn} className="bg-white/90 shadow-md" title="Zoom in">
          <ZoomIn className="h-4 w-4" />
        </Button>

        <Button variant="outline" size="icon" onClick={zoomOut} className="bg-white/90 shadow-md" title="Zoom out">
          <ZoomOut className="h-4 w-4" />
        </Button>

        <Button variant="outline" size="icon" onClick={resetView} className="bg-white/90 shadow-md" title="Reset view">
          <Compass className="h-4 w-4" />
        </Button>

        <Button
          variant="outline"
          size="sm"
          onClick={toggleAbstractScale}
          className="bg-white/90 shadow-md mt-2"
          title="Toggle abstract view"
        >
          {showAbstractScale ? "Show Map View" : "Show Abstract View"}
        </Button>
      </div>
    </div>
  )
}
