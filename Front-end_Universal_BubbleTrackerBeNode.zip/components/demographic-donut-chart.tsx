"use client"
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from "chart.js"
import { Doughnut } from "react-chartjs-2"
import { useState } from "react"
import { Button } from "@/components/ui/button"

// Register required chart components
ChartJS.register(ArcElement, Tooltip, Legend)

// May 2024 voter data by age groups
const may2024Data = {
  labels: ["18-29", "30-44", "45-64", "65+"],
  datasets: [
    {
      label: "Voter Demographics",
      data: [21, 28, 32, 19],
      backgroundColor: [
        "rgba(0, 114, 178, 0.8)", // blue (colorblind friendly)
        "rgba(213, 94, 0, 0.8)", // vermillion (colorblind friendly)
        "rgba(204, 121, 167, 0.8)", // reddish purple (colorblind friendly)
        "rgba(0, 158, 115, 0.8)", // bluish green (colorblind friendly)
      ],
      borderColor: ["rgb(0, 114, 178)", "rgb(213, 94, 0)", "rgb(204, 121, 167)", "rgb(0, 158, 115)"],
      borderWidth: 1,
    },
  ],
}

// May 2024 voter data by region
const regionData = {
  labels: ["North West", "North East", "Central", "South West", "South East"],
  datasets: [
    {
      label: "Regional Distribution",
      data: [24, 19, 22, 18, 17],
      backgroundColor: [
        "rgba(27, 158, 119, 0.8)", // teal
        "rgba(217, 95, 2, 0.8)", // orange
        "rgba(117, 112, 179, 0.8)", // purple
        "rgba(231, 41, 138, 0.8)", // pink
        "rgba(102, 166, 30, 0.8)", // green
      ],
      borderColor: [
        "rgb(27, 158, 119)",
        "rgb(217, 95, 2)",
        "rgb(117, 112, 179)",
        "rgb(231, 41, 138)",
        "rgb(102, 166, 30)",
      ],
      borderWidth: 1,
    },
  ],
}

// May 2024 voter data by party outcome
const partyData = {
  labels: ["Labour", "Conservative", "Liberal Democrat", "Green", "Reform UK"],
  datasets: [
    {
      label: "Party Outcomes",
      data: [43.7, 24.3, 12.2, 8.3, 11.5],
      backgroundColor: [
        "rgba(228, 0, 59, 0.8)", // Labour red
        "rgba(0, 135, 220, 0.8)", // Conservative blue
        "rgba(250, 166, 26, 0.8)", // Lib Dem orange/yellow
        "rgba(106, 176, 35, 0.8)", // Green
        "rgba(18, 182, 207, 0.8)", // Reform UK teal
      ],
      borderColor: [
        "rgb(228, 0, 59)",
        "rgb(0, 135, 220)",
        "rgb(250, 166, 26)",
        "rgb(106, 176, 35)",
        "rgb(18, 182, 207)",
      ],
      borderWidth: 1,
    },
  ],
}

// May 2024 voter data by turnout
const turnoutData = {
  labels: ["High (70%+)", "Medium-High (65-69%)", "Medium (60-64%)", "Medium-Low (55-59%)", "Low (<55%)"],
  datasets: [
    {
      label: "Turnout Distribution",
      data: [15, 27, 33, 18, 7],
      backgroundColor: [
        "rgba(0, 158, 115, 0.8)", // high - green
        "rgba(0, 114, 178, 0.8)", // medium-high - blue
        "rgba(117, 112, 179, 0.8)", // medium - purple
        "rgba(213, 94, 0, 0.8)", // medium-low - orange
        "rgba(228, 0, 59, 0.8)", // low - red
      ],
      borderColor: ["rgb(0, 158, 115)", "rgb(0, 114, 178)", "rgb(117, 112, 179)", "rgb(213, 94, 0)", "rgb(228, 0, 59)"],
      borderWidth: 1,
    },
  ],
}

// Chart options
const baseOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: "bottom" as const,
      labels: {
        usePointStyle: true,
        padding: 20,
        font: {
          weight: "bold",
        },
      },
    },
    tooltip: {
      callbacks: {
        label: (context: any) => {
          const label = context.label || ""
          const value = context.raw
          const total = context.dataset.data.reduce((a: number, b: number) => a + b, 0)
          const percentage = Math.round((value / total) * 100)
          return `${label}: ${percentage}% (${value})`
        },
      },
    },
  },
  cutout: "60%",
  animation: {
    animateScale: true,
    animateRotate: true,
  },
}

// Chart types
type ChartType = "age" | "region" | "party" | "turnout"

export default function DemographicDonutChart() {
  const [chartType, setChartType] = useState<ChartType>("age")

  // Get data based on selected chart type
  const getChartData = () => {
    switch (chartType) {
      case "age":
        return may2024Data
      case "region":
        return regionData
      case "party":
        return partyData
      case "turnout":
        return turnoutData
      default:
        return may2024Data
    }
  }

  // Get title based on selected chart type
  const getChartTitle = () => {
    switch (chartType) {
      case "age":
        return "Voter Age Distribution - May 2024"
      case "region":
        return "Regional Distribution - May 2024"
      case "party":
        return "Party Outcomes - May 2024"
      case "turnout":
        return "Voter Turnout - May 2024"
      default:
        return "Voter Demographics - May 2024"
    }
  }

  return (
    <div className="w-full h-full flex flex-col items-center justify-center">
      <div className="w-full mb-4 flex justify-center gap-2">
        <Button variant={chartType === "age" ? "default" : "outline"} size="sm" onClick={() => setChartType("age")}>
          Age Groups
        </Button>
        <Button
          variant={chartType === "region" ? "default" : "outline"}
          size="sm"
          onClick={() => setChartType("region")}
        >
          Regions
        </Button>
        <Button variant={chartType === "party" ? "default" : "outline"} size="sm" onClick={() => setChartType("party")}>
          Party Outcomes
        </Button>
        <Button
          variant={chartType === "turnout" ? "default" : "outline"}
          size="sm"
          onClick={() => setChartType("turnout")}
        >
          Turnout
        </Button>
      </div>

      <h3 className="text-center font-bold mb-2">{getChartTitle()}</h3>

      <div className="w-full h-full max-h-[300px]">
        <Doughnut data={getChartData()} options={baseOptions} />
      </div>
    </div>
  )
}
