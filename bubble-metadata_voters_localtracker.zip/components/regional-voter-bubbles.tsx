"use client"

import type React from "react"

import { useEffect, useRef, useState } from "react"
import { useToast } from "@/hooks/use-toast"

// London boroughs data with approximate coordinates, voter populations, and postcode sectors
const londonBoroughsData = [
  {
    borough: "City of London",
    population: 0.01, // 10,000 voters (smaller population)
    turnout: 68,
    percentile: 72,
    density: 0.95,
    mainPostcodes: "EC1-EC4",
    coordinates: [0.51, 0.48], // Approximate center coordinates (normalized)
    x: 0,
    y: 0,
  },
  {
    borough: "Westminster",
    population: 0.22, // 220,000 voters
    turnout: 65,
    percentile: 80,
    density: 0.92,
    mainPostcodes: "W1, SW1",
    coordinates: [0.48, 0.47],
    x: 0,
    y: 0,
  },
  {
    borough: "Kensington and Chelsea",
    population: 0.16, // 160,000 voters
    turnout: 70,
    percentile: 85,
    density: 0.88,
    mainPostcodes: "SW3, SW5, SW7, W8, W10, W11",
    coordinates: [0.45, 0.47],
    x: 0,
    y: 0,
  },
  {
    borough: "Hammersmith and Fulham",
    population: 0.18, // 180,000 voters
    turnout: 67,
    percentile: 75,
    density: 0.82,
    mainPostcodes: "W6, W12, W14, SW6",
    coordinates: [0.42, 0.47],
    x: 0,
    y: 0,
  },
  {
    borough: "Wandsworth",
    population: 0.32, // 320,000 voters
    turnout: 69,
    percentile: 78,
    density: 0.79,
    mainPostcodes: "SW11, SW12, SW15, SW17, SW18, SW19",
    coordinates: [0.45, 0.52],
    x: 0,
    y: 0,
  },
  {
    borough: "Lambeth",
    population: 0.33, // 330,000 voters
    turnout: 63,
    percentile: 68,
    density: 0.85,
    mainPostcodes: "SE1, SE5, SE11, SE21, SE24, SE27, SW2, SW4, SW8, SW9, SW16",
    coordinates: [0.49, 0.53],
    x: 0,
    y: 0,
  },
  {
    borough: "Southwark",
    population: 0.31, // 310,000 voters
    turnout: 62,
    percentile: 65,
    density: 0.83,
    mainPostcodes: "SE1, SE5, SE15, SE16, SE17, SE21, SE22, SE24",
    coordinates: [0.52, 0.52],
    x: 0,
    y: 0,
  },
  {
    borough: "Tower Hamlets",
    population: 0.29, // 290,000 voters
    turnout: 59,
    percentile: 62,
    density: 0.87,
    mainPostcodes: "E1, E2, E3, E14",
    coordinates: [0.54, 0.47],
    x: 0,
    y: 0,
  },
  {
    borough: "Hackney",
    population: 0.27, // 270,000 voters
    turnout: 58,
    percentile: 60,
    density: 0.86,
    mainPostcodes: "E2, E5, E8, E9, N1, N16",
    coordinates: [0.53, 0.44],
    x: 0,
    y: 0,
  },
  {
    borough: "Islington",
    population: 0.23, // 230,000 voters
    turnout: 64,
    percentile: 70,
    density: 0.89,
    mainPostcodes: "EC1, N1, N4, N5, N7, N19",
    coordinates: [0.5, 0.43],
    x: 0,
    y: 0,
  },
  {
    borough: "Camden",
    population: 0.24, // 240,000 voters
    turnout: 66,
    percentile: 75,
    density: 0.84,
    mainPostcodes: "NW1, NW3, NW5, WC1, WC2",
    coordinates: [0.47, 0.43],
    x: 0,
    y: 0,
  },
  {
    borough: "Brent",
    population: 0.33, // 330,000 voters
    turnout: 61,
    percentile: 58,
    density: 0.76,
    mainPostcodes: "HA0, HA9, NW2, NW6, NW9, NW10",
    coordinates: [0.42, 0.4],
    x: 0,
    y: 0,
  },
  {
    borough: "Ealing",
    population: 0.34, // 340,000 voters
    turnout: 63,
    percentile: 62,
    density: 0.74,
    mainPostcodes: "UB5, UB6, W3, W5, W7, W13",
    coordinates: [0.37, 0.43],
    x: 0,
    y: 0,
  },
  {
    borough: "Hounslow",
    population: 0.27, // 270,000 voters
    turnout: 62,
    percentile: 59,
    density: 0.71,
    mainPostcodes: "TW3, TW4, TW5, TW7, TW8, TW13, TW14, W4",
    coordinates: [0.33, 0.45],
    x: 0,
    y: 0,
  },
  {
    borough: "Richmond upon Thames",
    population: 0.19, // 190,000 voters
    turnout: 72,
    percentile: 82,
    density: 0.68,
    mainPostcodes: "SW13, SW14, TW1, TW2, TW9, TW10, TW11, TW12",
    coordinates: [0.36, 0.5],
    x: 0,
    y: 0,
  },
  {
    borough: "Kingston upon Thames",
    population: 0.17, // 170,000 voters
    turnout: 70,
    percentile: 78,
    density: 0.65,
    mainPostcodes: "KT1, KT2, KT3, KT5, KT6, KT9",
    coordinates: [0.38, 0.55],
    x: 0,
    y: 0,
  },
  {
    borough: "Merton",
    population: 0.21, // 210,000 voters
    turnout: 67,
    percentile: 72,
    density: 0.7,
    mainPostcodes: "CR4, SM4, SW19, SW20",
    coordinates: [0.42, 0.55],
    x: 0,
    y: 0,
  },
  {
    borough: "Sutton",
    population: 0.2, // 200,000 voters
    turnout: 68,
    percentile: 70,
    density: 0.62,
    mainPostcodes: "CR0, CR4, KT4, SM1, SM2, SM3, SM5, SM6, SM7",
    coordinates: [0.45, 0.6],
    x: 0,
    y: 0,
  },
  {
    borough: "Croydon",
    population: 0.38, // 380,000 voters
    turnout: 64,
    percentile: 65,
    density: 0.73,
    mainPostcodes: "CR0, CR2, CR7, CR8, SE19, SE25",
    coordinates: [0.5, 0.62],
    x: 0,
    y: 0,
  },
  {
    borough: "Bromley",
    population: 0.33, // 330,000 voters
    turnout: 69,
    percentile: 73,
    density: 0.6,
    mainPostcodes: "BR1, BR2, BR3, BR4, BR5, BR6, BR7, SE20",
    coordinates: [0.57, 0.6],
    x: 0,
    y: 0,
  },
  {
    borough: "Lewisham",
    population: 0.3, // 300,000 voters
    turnout: 61,
    percentile: 64,
    density: 0.78,
    mainPostcodes: "SE3, SE4, SE6, SE8, SE9, SE10, SE12, SE13, SE14, SE23, SE26",
    coordinates: [0.55, 0.55],
    x: 0,
    y: 0,
  },
  {
    borough: "Greenwich",
    population: 0.28, // 280,000 voters
    turnout: 63,
    percentile: 67,
    density: 0.75,
    mainPostcodes: "SE2, SE3, SE7, SE8, SE9, SE10, SE18, SE28",
    coordinates: [0.58, 0.52],
    x: 0,
    y: 0,
  },
  {
    borough: "Bexley",
    population: 0.24, // 240,000 voters
    turnout: 65,
    percentile: 68,
    density: 0.67,
    mainPostcodes: "DA1, DA5, DA6, DA7, DA8, DA14, DA15, DA16, DA17, DA18",
    coordinates: [0.63, 0.5],
    x: 0,
    y: 0,
  },
  {
    borough: "Havering",
    population: 0.25, // 250,000 voters
    turnout: 66,
    percentile: 69,
    density: 0.63,
    mainPostcodes: "RM1, RM2, RM3, RM4, RM5, RM7, RM8, RM9, RM10, RM11, RM12, RM13, RM14",
    coordinates: [0.67, 0.45],
    x: 0,
    y: 0,
  },
  {
    borough: "Barking and Dagenham",
    population: 0.21, // 210,000 voters
    turnout: 57,
    percentile: 52,
    density: 0.72,
    mainPostcodes: "IG11, RM8, RM9, RM10",
    coordinates: [0.62, 0.45],
    x: 0,
    y: 0,
  },
  {
    borough: "Redbridge",
    population: 0.3, // 300,000 voters
    turnout: 62,
    percentile: 64,
    density: 0.74,
    mainPostcodes: "E11, E12, E18, IG1, IG2, IG3, IG4, IG5, IG6, IG8",
    coordinates: [0.6, 0.4],
    x: 0,
    y: 0,
  },
  {
    borough: "Newham",
    population: 0.34, // 340,000 voters
    turnout: 56,
    percentile: 54,
    density: 0.85,
    mainPostcodes: "E3, E6, E7, E12, E13, E15, E16, E20",
    coordinates: [0.57, 0.44],
    x: 0,
    y: 0,
  },
  {
    borough: "Waltham Forest",
    population: 0.27, // 270,000 voters
    turnout: 59,
    percentile: 61,
    density: 0.79,
    mainPostcodes: "E4, E5, E10, E11, E17",
    coordinates: [0.55, 0.38],
    x: 0,
    y: 0,
  },
  {
    borough: "Haringey",
    population: 0.27, // 270,000 voters
    turnout: 61,
    percentile: 63,
    density: 0.81,
    mainPostcodes: "N4, N6, N8, N10, N11, N15, N17, N22",
    coordinates: [0.5, 0.38],
    x: 0,
    y: 0,
  },
  {
    borough: "Enfield",
    population: 0.33, // 330,000 voters
    turnout: 64,
    percentile: 66,
    density: 0.72,
    mainPostcodes: "EN1, EN2, EN3, EN4, N9, N13, N14, N18, N21",
    coordinates: [0.5, 0.33],
    x: 0,
    y: 0,
  },
  {
    borough: "Barnet",
    population: 0.38, // 380,000 voters
    turnout: 67,
    percentile: 71,
    density: 0.73,
    mainPostcodes: "EN4, EN5, HA8, N2, N3, N11, N12, N14, N20, NW4, NW7, NW9, NW11",
    coordinates: [0.45, 0.35],
    x: 0,
    y: 0,
  },
  {
    borough: "Harrow",
    population: 0.25, // 250,000 voters
    turnout: 65,
    percentile: 68,
    density: 0.71,
    mainPostcodes: "HA1, HA2, HA3, HA4, HA5, HA7, HA8",
    coordinates: [0.4, 0.35],
    x: 0,
    y: 0,
  },
  {
    borough: "Hillingdon",
    population: 0.3, // 300,000 voters
    turnout: 64,
    percentile: 67,
    density: 0.68,
    mainPostcodes: "HA4, HA5, HA6, UB1, UB3, UB4, UB7, UB8, UB9, UB10, UB11",
    coordinates: [0.33, 0.38],
    x: 0,
    y: 0,
  },
]

// Color mapping for boroughs based on voter turnout
function getTurnoutColor(turnout: number): string {
  if (turnout >= 70) return "#4ade80" // high turnout - green
  if (turnout >= 65) return "#60a5fa" // medium-high turnout - blue
  if (turnout >= 60) return "#a78bfa" // medium turnout - purple
  if (turnout >= 55) return "#f97316" // medium-low turnout - orange
  return "#f87171" // low turnout - red
}

// Function to calculate distance between two points
function calculateDistance(x1: number, y1: number, x2: number, y2: number): number {
  return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2))
}

// Function to calculate point inside polygon (ray casting algorithm)
function isPointInPolygon(point: [number, number], polygon: [number, number][]): boolean {
  const x = point[0],
    y = point[1]
  let inside = false

  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const xi = polygon[i][0],
      yi = polygon[i][1]
    const xj = polygon[j][0],
      yj = polygon[j][1]

    const intersect = yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi
    if (intersect) inside = !inside
  }

  return inside
}

export default function RegionalVoterBubbles() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [hoveredBorough, setHoveredBorough] = useState<string | null>(null)
  const [selectedBorough, setSelectedBorough] = useState<string | null>(null)
  const [tooltipPosition, setTooltipPosition] = useState({ x: 0, y: 0 })
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const { toast } = useToast()

  // Function to draw the London boroughs map
  const drawLondonMap = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions
    const parentWidth = canvas.parentElement?.clientWidth || 400
    const parentHeight = canvas.parentElement?.clientHeight || 400

    // Set the canvas size with higher resolution for retina displays
    canvas.width = parentWidth * 2
    canvas.height = parentHeight * 2
    canvas.style.width = `${parentWidth}px`
    canvas.style.height = `${parentHeight}px`
    ctx.scale(2, 2)

    // Clear canvas
    ctx.clearRect(0, 0, parentWidth, parentHeight)

    // Draw background
    ctx.fillStyle = "#f8fafc" // very light gray background
    ctx.fillRect(0, 0, parentWidth, parentHeight)

    // Draw Thames river path (simplified)
    ctx.beginPath()
    ctx.moveTo(parentWidth * 0.3, parentHeight * 0.48) // West
    ctx.bezierCurveTo(
      parentWidth * 0.4,
      parentHeight * 0.47,
      parentWidth * 0.45,
      parentHeight * 0.48,
      parentWidth * 0.5,
      parentHeight * 0.48,
    )
    ctx.bezierCurveTo(
      parentWidth * 0.55,
      parentHeight * 0.48,
      parentWidth * 0.6,
      parentHeight * 0.5,
      parentWidth * 0.7,
      parentHeight * 0.48,
    )
    ctx.lineWidth = 4
    ctx.strokeStyle = "#bfdbfe" // light blue
    ctx.stroke()

    // Fill river
    ctx.lineWidth = 10
    ctx.strokeStyle = "#93c5fd" // blue
    ctx.stroke()

    // Draw borough bubbles
    londonBoroughsData.forEach((borough) => {
      // Scale coordinates to canvas size
      const x = borough.coordinates[0] * parentWidth
      const y = borough.coordinates[1] * parentHeight

      // Store the position for interaction
      borough.x = x
      borough.y = y

      // Calculate bubble size based on population
      const radius = Math.sqrt(borough.population * 1000) * 5

      // Draw bubble
      ctx.beginPath()
      ctx.arc(x, y, radius, 0, Math.PI * 2)

      // Fill with color based on turnout
      const isActive = hoveredBorough === borough.borough || selectedBorough === borough.borough
      const baseColor = getTurnoutColor(borough.turnout)
      ctx.fillStyle = isActive ? baseColor : `${baseColor}80` // More transparent when not active
      ctx.fill()

      // Draw border
      ctx.strokeStyle = baseColor
      ctx.lineWidth = isActive ? 2 : 1
      ctx.stroke()

      // Draw borough name
      ctx.fillStyle = "#1e293b" // dark blue-gray
      ctx.font = isActive ? "bold 10px sans-serif" : "10px sans-serif"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"

      // Adjust text position based on bubble size
      if (radius > 15) {
        ctx.fillText(borough.borough, x, y)
      } else if (isActive) {
        ctx.fillText(borough.borough, x, y - radius - 8)
      }

      // Draw percentile indicator for selected borough
      if (isActive) {
        const percentileRadius = 15
        const percentileAngle = (borough.percentile / 100) * Math.PI * 2

        ctx.beginPath()
        ctx.arc(x, y + radius + 15, percentileRadius, 0, Math.PI * 2)
        ctx.strokeStyle = "#64748b" // slate
        ctx.lineWidth = 1
        ctx.stroke()

        ctx.beginPath()
        ctx.moveTo(x, y + radius + 15)
        ctx.arc(x, y + radius + 15, percentileRadius, -Math.PI / 2, percentileAngle - Math.PI / 2)
        ctx.lineTo(x, y + radius + 15)
        ctx.closePath()

        ctx.fillStyle = baseColor
        ctx.fill()

        // Draw percentile text
        ctx.fillStyle = "#1e293b"
        ctx.font = "10px sans-serif"
        ctx.fillText(`${borough.percentile}%`, x, y + radius + 15)
      }
    })

    // Draw distance-based estimate for mouse position
    if (mousePosition.x > 0 && mousePosition.y > 0 && !hoveredBorough) {
      const mx = mousePosition.x
      const my = mousePosition.y

      // Find nearest boroughs
      const boroughDistances = londonBoroughsData
        .map((borough) => ({
          borough: borough.borough,
          distance: calculateDistance(mx, my, borough.x, borough.y),
          population: borough.population,
          turnout: borough.turnout,
        }))
        .sort((a, b) => a.distance - b.distance)

      // Get the 3 nearest boroughs
      const nearestBoroughs = boroughDistances.slice(0, 3)

      // Calculate weighted voter estimate based on distance
      const totalWeight = nearestBoroughs.reduce((sum, b) => sum + 1 / Math.max(b.distance, 1), 0)
      const weightedPopulation = nearestBoroughs.reduce(
        (sum, b) => sum + (b.population * (1 / Math.max(b.distance, 1))) / totalWeight,
        0,
      )
      const weightedTurnout = nearestBoroughs.reduce(
        (sum, b) => sum + (b.turnout * (1 / Math.max(b.distance, 1))) / totalWeight,
        0,
      )

      // Draw estimate indicator
      ctx.beginPath()
      ctx.arc(mx, my, 5, 0, Math.PI * 2)
      ctx.fillStyle = "rgba(100, 116, 139, 0.5)" // slate with transparency
      ctx.fill()

      ctx.beginPath()
      ctx.arc(mx, my, 30, 0, Math.PI * 2)
      ctx.strokeStyle = "rgba(100, 116, 139, 0.3)"
      ctx.setLineDash([3, 3])
      ctx.lineWidth = 1
      ctx.stroke()
      ctx.setLineDash([])

      // Draw estimate text
      ctx.fillStyle = "#1e293b"
      ctx.font = "10px sans-serif"
      ctx.textAlign = "center"
      ctx.fillText(`Est. ${(weightedPopulation * 1000000).toFixed(0)} voters`, mx, my + 20)
      ctx.fillText(`Est. ${weightedTurnout.toFixed(1)}% turnout`, mx, my + 35)
    }

    // Draw legend
    const legendX = 20
    const legendY = 20
    const legendWidth = 150
    const legendHeight = 120

    // Legend background
    ctx.fillStyle = "rgba(255, 255, 255, 0.8)"
    ctx.fillRect(legendX, legendY, legendWidth, legendHeight)
    ctx.strokeStyle = "#e2e8f0"
    ctx.lineWidth = 1
    ctx.strokeRect(legendX, legendY, legendWidth, legendHeight)

    // Legend title
    ctx.fillStyle = "#1e293b"
    ctx.font = "bold 12px sans-serif"
    ctx.textAlign = "left"
    ctx.textBaseline = "middle"
    ctx.fillText("London Voter Data", legendX + 10, legendY + 15)

    // Legend subtitle
    ctx.fillStyle = "#64748b"
    ctx.font = "10px sans-serif"
    ctx.fillText("10 million voters across 33 boroughs", legendX + 10, legendY + 30)

    // Legend items - turnout colors
    const turnoutLevels = [
      { label: "High turnout (70%+)", color: getTurnoutColor(70) },
      { label: "Medium-high (65-69%)", color: getTurnoutColor(65) },
      { label: "Medium (60-64%)", color: getTurnoutColor(60) },
      { label: "Medium-low (55-59%)", color: getTurnoutColor(55) },
      { label: "Low turnout (<55%)", color: getTurnoutColor(50) },
    ]

    turnoutLevels.forEach((level, i) => {
      const y = legendY + 45 + i * 15

      // Draw color circle
      ctx.beginPath()
      ctx.arc(legendX + 15, y, 6, 0, Math.PI * 2)
      ctx.fillStyle = level.color
      ctx.fill()

      // Draw label
      ctx.fillStyle = "#1e293b"
      ctx.font = "10px sans-serif"
      ctx.textAlign = "left"
      ctx.textBaseline = "middle"
      ctx.fillText(level.label, legendX + 30, y)
    })

    // Draw postcode sector info
    if (selectedBorough) {
      const borough = londonBoroughsData.find((b) => b.borough === selectedBorough)
      if (borough) {
        const infoX = parentWidth - 170
        const infoY = 20
        const infoWidth = 150
        const infoHeight = 80

        // Info background
        ctx.fillStyle = "rgba(255, 255, 255, 0.8)"
        ctx.fillRect(infoX, infoY, infoWidth, infoHeight)
        ctx.strokeStyle = "#e2e8f0"
        ctx.lineWidth = 1
        ctx.strokeRect(infoX, infoY, infoWidth, infoHeight)

        // Borough name
        ctx.fillStyle = "#1e293b"
        ctx.font = "bold 12px sans-serif"
        ctx.textAlign = "left"
        ctx.textBaseline = "middle"
        ctx.fillText(borough.borough, infoX + 10, infoY + 15)

        // Postcode sectors
        ctx.fillStyle = "#64748b"
        ctx.font = "10px sans-serif"
        ctx.fillText("Postcode sectors:", infoX + 10, infoY + 35)

        // Wrap postcode text
        const postcodes = borough.mainPostcodes.split(", ")
        let postcodeLine = ""
        let lineY = infoY + 50

        postcodes.forEach((postcode) => {
          if ((postcodeLine + postcode).length > 20) {
            ctx.fillText(postcodeLine, infoX + 10, lineY)
            postcodeLine = postcode + ", "
            lineY += 15
          } else {
            postcodeLine += postcode + ", "
          }
        })

        // Print the last line
        if (postcodeLine) {
          ctx.fillText(postcodeLine.slice(0, -2), infoX + 10, lineY)
        }
      }
    }
  }

  // Handle mouse move for hover effects
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current
    if (!canvas) return

    const rect = canvas.getBoundingClientRect()
    const x = (e.clientX - rect.left) * (canvas.width / rect.width / 2)
    const y = (e.clientY - rect.top) * (canvas.height / rect.height / 2)

    setMousePosition({ x, y })

    // Check if mouse is over any borough
    let found = false
    for (const borough of londonBoroughsData) {
      const dx = x - borough.x
      const dy = y - borough.y
      const distance = Math.sqrt(dx * dx + dy * dy)
      const radius = Math.sqrt(borough.population * 1000) * 5

      if (distance <= radius) {
        setHoveredBorough(borough.borough)
        setTooltipPosition({ x: e.clientX, y: e.clientY })
        found = true
        break
      }
    }

    if (!found && hoveredBorough !== null) {
      setHoveredBorough(null)
    }
  }

  // Handle click on boroughs
  const handleClick = () => {
    if (hoveredBorough !== null) {
      setSelectedBorough(hoveredBorough === selectedBorough ? null : hoveredBorough)

      const borough = londonBoroughsData.find((b) => b.borough === hoveredBorough)
      if (borough) {
        toast({
          title: borough.borough,
          description: `Population: ${(borough.population * 1000000).toFixed(0)} voters, Turnout: ${borough.turnout}%, Main postcodes: ${borough.mainPostcodes}`,
        })
      }
    } else {
      setSelectedBorough(null)
    }
  }

  // Initialize and draw map on component mount
  useEffect(() => {
    drawLondonMap()

    const handleResize = () => {
      drawLondonMap()
    }

    window.addEventListener("resize", handleResize)
    return () => {
      window.removeEventListener("resize", handleResize)
    }
  }, [hoveredBorough, selectedBorough, mousePosition])

  return (
    <div className="relative w-full h-full flex items-center justify-center">
      <canvas ref={canvasRef} className="cursor-pointer" onMouseMove={handleMouseMove} onClick={handleClick} />

      {hoveredBorough !== null && (
        <div
          className="absolute z-50 bg-background border rounded-md shadow-md p-2 text-sm pointer-events-none"
          style={{
            left: `${tooltipPosition.x + 10}px`,
            top: `${tooltipPosition.y + 10}px`,
            transform: "translateX(-50%)",
          }}
        >
          {(() => {
            const borough = londonBoroughsData.find((b) => b.borough === hoveredBorough)
            return borough ? (
              <div>
                <div className="font-bold">{borough.borough}</div>
                <div>Population: {(borough.population * 1000000).toFixed(0)} voters</div>
                <div>Voter Turnout: {borough.turnout}%</div>
                <div>Concentration Percentile: {borough.percentile}%</div>
                <div>Main Postcodes: {borough.mainPostcodes}</div>
              </div>
            ) : null
          })()}
        </div>
      )}

      <div className="absolute bottom-4 left-4 text-xs text-muted-foreground">
        Click on a borough to see detailed postcode information
      </div>
    </div>
  )
}

