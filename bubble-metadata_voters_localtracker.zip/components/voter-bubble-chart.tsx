"use client"

import type React from "react"

import { useEffect, useRef, useState } from "react"
import { useToast } from "@/hooks/use-toast"
import { useMobile } from "@/hooks/use-mobile"

// Sample data for the bubble chart
const voterData = [
  { id: 1, group: "18-29", subgroup: "College", value: 28, turnout: 42 },
  { id: 2, group: "18-29", subgroup: "No College", value: 32, turnout: 35 },
  { id: 3, group: "30-44", subgroup: "College", value: 45, turnout: 65 },
  { id: 4, group: "30-44", subgroup: "No College", value: 38, turnout: 52 },
  { id: 5, group: "45-64", subgroup: "College", value: 52, turnout: 78 },
  { id: 6, group: "45-64", subgroup: "No College", value: 48, turnout: 68 },
  { id: 7, group: "65+", subgroup: "College", value: 35, turnout: 82 },
  { id: 8, group: "65+", subgroup: "No College", value: 30, turnout: 75 },
  { id: 9, group: "18-29", subgroup: "Urban", value: 40, turnout: 45 },
  { id: 10, group: "30-44", subgroup: "Urban", value: 55, turnout: 68 },
  { id: 11, group: "45-64", subgroup: "Urban", value: 60, turnout: 75 },
  { id: 12, group: "65+", subgroup: "Urban", value: 42, turnout: 80 },
]

// Color scale for different groups with a more pleasant palette
const colorScale: Record<string, string> = {
  "18-29": "#6366f1", // indigo
  "30-44": "#8b5cf6", // purple
  "45-64": "#ec4899", // pink
  "65+": "#f97316", // orange
}

export default function VoterBubbleChart() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [hoveredBubble, setHoveredBubble] = useState<number | null>(null)
  const [tooltipPosition, setTooltipPosition] = useState({ x: 0, y: 0 })
  const { toast } = useToast()
  const isMobile = useMobile()

  // Function to draw the bubble chart
  const drawBubbleChart = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions
    const parentWidth = canvas.parentElement?.clientWidth || 400
    const parentHeight = canvas.parentElement?.clientHeight || 400

    // Set the canvas size with higher resolution for retina displays
    canvas.width = parentWidth * 2
    canvas.height = parentHeight * 2
    canvas.style.width = `${parentWidth}px`
    canvas.style.height = `${parentHeight}px`
    ctx.scale(2, 2)

    // Clear canvas
    ctx.clearRect(0, 0, parentWidth, parentHeight)

    // Calculate the center and radius for the bubble layout
    const centerX = parentWidth / 2
    const centerY = parentHeight / 2
    const maxRadius = Math.min(centerX, centerY) * 0.85

    // Draw background grid
    ctx.strokeStyle = "#e5e7eb"
    ctx.lineWidth = 1

    // Draw concentric circles
    for (let i = 1; i <= 4; i++) {
      ctx.beginPath()
      ctx.arc(centerX, centerY, maxRadius * (i / 4), 0, Math.PI * 2)
      ctx.stroke()
    }

    // Draw radial lines
    for (let i = 0; i < 8; i++) {
      const angle = (i * Math.PI) / 4
      ctx.beginPath()
      ctx.moveTo(centerX, centerY)
      ctx.lineTo(centerX + Math.cos(angle) * maxRadius, centerY + Math.sin(angle) * maxRadius)
      ctx.stroke()
    }

    // Group data by age group
    const groupedData: Record<string, typeof voterData> = {}
    voterData.forEach((item) => {
      if (!groupedData[item.group]) {
        groupedData[item.group] = []
      }
      groupedData[item.group].push(item)
    })

    // Draw bubbles for each group in a circular arrangement
    Object.entries(groupedData).forEach(([group, items], groupIndex) => {
      const groupAngle = (groupIndex * Math.PI) / 2 // Divide the circle into 4 quadrants
      const groupRadius = maxRadius * 0.7 // Position groups at 70% of the max radius

      // Calculate group center position
      const groupCenterX = centerX + Math.cos(groupAngle) * groupRadius
      const groupCenterY = centerY + Math.sin(groupAngle) * groupRadius

      // Draw group label
      ctx.fillStyle = "#000000"
      ctx.font = "bold 12px sans-serif"
      ctx.textAlign = "center"
      ctx.fillText(group, groupCenterX, groupCenterY - 40)

      // Draw bubbles within this group
      items.forEach((item, itemIndex) => {
        // Calculate bubble position in a small cluster around the group center
        const angle = (itemIndex * Math.PI * 2) / items.length
        const distance = 30 + (item.turnout / 100) * 20 // Vary distance based on turnout

        const x = groupCenterX + Math.cos(angle) * distance
        const y = groupCenterY + Math.sin(angle) * distance

        // Calculate bubble size based on value
        const radius = 10 + (item.value / 60) * 20

        // Draw bubble
        ctx.beginPath()
        ctx.arc(x, y, radius, 0, Math.PI * 2)

        // Fill with group color
        ctx.fillStyle =
          hoveredBubble === item.id
            ? `${colorScale[item.group]}cc` // Lighter version when hovered
            : `${colorScale[item.group]}99` // Semi-transparent

        ctx.fill()

        // Draw border
        ctx.strokeStyle = colorScale[item.group]
        ctx.lineWidth = hoveredBubble === item.id ? 3 : 1
        ctx.stroke()

        // Store bubble data for interaction
        item.x = x
        item.y = y
        item.radius = radius
      })
    })
  }

  // Handle mouse move for hover effects
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current
    if (!canvas) return

    const rect = canvas.getBoundingClientRect()
    const x = (e.clientX - rect.left) * (canvas.width / rect.width / 2)
    const y = (e.clientY - rect.top) * (canvas.height / rect.height / 2)

    // Check if mouse is over any bubble
    let found = false
    for (const item of voterData) {
      if (!("x" in item) || !("y" in item) || !("radius" in item)) continue

      const dx = x - item.x
      const dy = y - item.y
      const distance = Math.sqrt(dx * dx + dy * dy)

      if (distance <= item.radius) {
        setHoveredBubble(item.id)
        setTooltipPosition({ x: e.clientX, y: e.clientY })
        found = true
        break
      }
    }

    if (!found && hoveredBubble !== null) {
      setHoveredBubble(null)
    }
  }

  // Handle click on bubbles
  const handleClick = () => {
    if (hoveredBubble !== null) {
      const item = voterData.find((d) => d.id === hoveredBubble)
      if (item) {
        toast({
          title: `${item.group} - ${item.subgroup}`,
          description: `Population: ${item.value}%, Turnout: ${item.turnout}%`,
        })
      }
    }
  }

  // Draw chart on component mount and when window resizes
  useEffect(() => {
    drawBubbleChart()

    const handleResize = () => {
      drawBubbleChart()
    }

    window.addEventListener("resize", handleResize)
    return () => {
      window.removeEventListener("resize", handleResize)
    }
  }, [hoveredBubble])

  return (
    <div className="relative w-full h-full flex items-center justify-center">
      <canvas ref={canvasRef} className="cursor-pointer" onMouseMove={handleMouseMove} onClick={handleClick} />

      {hoveredBubble !== null && !isMobile && (
        <div
          className="absolute z-50 bg-background border rounded-md shadow-md p-2 text-sm pointer-events-none"
          style={{
            left: `${tooltipPosition.x + 10}px`,
            top: `${tooltipPosition.y + 10}px`,
            transform: "translateX(-50%)",
          }}
        >
          {(() => {
            const item = voterData.find((d) => d.id === hoveredBubble)
            return item ? (
              <div>
                <div className="font-bold">
                  {item.group} - {item.subgroup}
                </div>
                <div>Population: {item.value}%</div>
                <div>Voter Turnout: {item.turnout}%</div>
              </div>
            ) : null
          })()}
        </div>
      )}

      <div className="absolute bottom-2 right-2 flex flex-col gap-1">
        {Object.entries(colorScale).map(([group, color]) => (
          <div key={group} className="flex items-center gap-1 text-xs">
            <div className="w-3 h-3 rounded-full" style={{ backgroundColor: color }}></div>
            <span>{group}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

