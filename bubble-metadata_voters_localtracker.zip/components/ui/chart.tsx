import {
  type Chart as ChartJS,
  type ChartData as ChartJSData,
  type ChartOptions as ChartJSOptions,
  ArcElement as ChartJSArcElement,
  Tooltip as ChartJSTooltip,
  Legend as ChartJSLegend,
} from "chart.js/auto"
import { forwardRef } from "react"

export const Chart = forwardRef<ChartJS, any>((props, ref) => {
  return <canvas ref={ref} {...props} />
})

Chart.displayName = "Chart"

export type Chart = ChartJS
export type ChartData<T extends keyof ChartJS._adapters._scriptable> = ChartJSData<T>
export type ChartOptions<T extends keyof ChartJS._adapters._scriptable> = ChartJSOptions<T>
export const ArcElement = ChartJSArcElement
export const Tooltip = ChartJSTooltip
export const Legend = ChartJSLegend

