"use client"

import type React from "react"

import { useEffect, useRef, useState } from "react"
import { useToast } from "@/hooks/use-toast"

// Updated data for the circular plot covering 2011 to 2025
const votingTrends = [
  { year: 2011, conservative: 36.1, labour: 29.0, reform: 3.1 },
  { year: 2012, conservative: 35.7, labour: 32.4, reform: 3.5 },
  { year: 2013, conservative: 33.2, labour: 38.1, reform: 4.2 },
  { year: 2014, conservative: 31.5, labour: 36.9, reform: 10.8 }, // UKIP rise
  { year: 2015, conservative: 36.9, labour: 30.4, reform: 12.6 }, // General Election
  { year: 2016, conservative: 38.0, labour: 31.5, reform: 14.0 }, // Brexit referendum year
  { year: 2017, conservative: 42.4, labour: 40.0, reform: 1.8 }, // General Election
  { year: 2018, conservative: 40.2, labour: 38.5, reform: 5.2 },
  { year: 2019, conservative: 43.6, labour: 32.1, reform: 2.0 }, // General Election
  { year: 2020, conservative: 40.5, labour: 35.2, reform: 3.5 },
  { year: 2021, conservative: 38.2, labour: 37.8, reform: 4.2 },
  { year: 2022, conservative: 32.5, labour: 40.3, reform: 5.8 },
  { year: 2023, conservative: 28.7, labour: 44.2, reform: 8.5 },
  { year: 2024, conservative: 24.3, labour: 33.7, reform: 14.3 }, // General Election
  { year: 2025, conservative: 26.5, labour: 32.0, reform: 16.2 }, // Projection
]

export default function VotingTrendsCircularPlot() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [selectedYear, setSelectedYear] = useState<number | null>(null)
  const [tooltipPosition, setTooltipPosition] = useState({ x: 0, y: 0 })
  const { toast } = useToast()

  // Function to draw the circular plot
  const drawCircularPlot = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions
    const parentWidth = canvas.parentElement?.clientWidth || 400
    const parentHeight = canvas.parentElement?.clientHeight || 400

    // Set the canvas size with higher resolution for retina displays
    canvas.width = parentWidth * 2
    canvas.height = parentHeight * 2
    canvas.style.width = `${parentWidth}px`
    canvas.style.height = `${parentHeight}px`
    ctx.scale(2, 2)

    // Clear canvas
    ctx.clearRect(0, 0, parentWidth, parentHeight)

    // Calculate the center and radius
    const centerX = parentWidth / 2
    const centerY = parentHeight / 2
    const maxRadius = Math.min(centerX, centerY) * 0.8

    // Draw background circle
    ctx.beginPath()
    ctx.arc(centerX, centerY, maxRadius, 0, Math.PI * 2)
    ctx.fillStyle = "#f9fafb"
    ctx.fill()
    ctx.strokeStyle = "#e5e7eb"
    ctx.lineWidth = 1
    ctx.stroke()

    // Draw concentric circles for reference
    for (let i = 1; i <= 4; i++) {
      ctx.beginPath()
      ctx.arc(centerX, centerY, maxRadius * (i / 4), 0, Math.PI * 2)
      ctx.strokeStyle = "#e5e7eb"
      ctx.stroke()
    }

    // Draw years as segments around the circle
    const yearCount = votingTrends.length
    const segmentAngle = (Math.PI * 2) / yearCount

    votingTrends.forEach((data, index) => {
      const startAngle = index * segmentAngle - Math.PI / 2 // Start from top (12 o'clock)
      const endAngle = startAngle + segmentAngle
      const midAngle = startAngle + segmentAngle / 2

      // Draw year label
      const labelRadius = maxRadius * 1.1
      const labelX = centerX + Math.cos(midAngle) * labelRadius
      const labelY = centerY + Math.sin(midAngle) * labelRadius

      // Adjust font size for more years
      const fontSize = yearCount > 10 ? 10 : 12

      ctx.fillStyle = selectedYear === data.year ? "#000000" : "#6b7280"
      ctx.font = selectedYear === data.year ? `bold ${fontSize}px sans-serif` : `${fontSize}px sans-serif`
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(data.year.toString(), labelX, labelY)

      // Draw arcs for each party
      const drawArc = (startRadius: number, endRadius: number, color: string) => {
        ctx.beginPath()
        ctx.arc(centerX, centerY, startRadius, startAngle, endAngle)
        ctx.arc(centerX, centerY, endRadius, endAngle, startAngle, true)
        ctx.closePath()
        ctx.fillStyle = selectedYear === data.year ? color : `${color}40` // More transparent when not selected
        ctx.fill()
        ctx.strokeStyle = color
        ctx.lineWidth = selectedYear === data.year ? 1.5 : 0.5 // Thinner lines for more segments
        ctx.stroke()
      }

      // Calculate radii based on percentages
      const innerRadius = maxRadius * 0.3 // Inner empty circle
      const conservativeRadius = innerRadius + (maxRadius - innerRadius) * (data.conservative / 100)
      const labourRadius = conservativeRadius + (maxRadius - innerRadius) * (data.labour / 100)

      // Draw arcs from inside out
      drawArc(innerRadius, conservativeRadius, "#3b82f6") // Conservative Party (blue)
      drawArc(conservativeRadius, labourRadius, "#ef4444") // Labour Party (red)
      drawArc(labourRadius, maxRadius, "#0078D7") // Reform UK (Windows blue screen color)

      // Store segment data for interaction
      data.startAngle = startAngle
      data.endAngle = endAngle
      data.innerRadius = innerRadius
      data.outerRadius = maxRadius
    })

    // Draw center text
    if (selectedYear) {
      const selectedData = votingTrends.find((d) => d.year === selectedYear)
      if (selectedData) {
        ctx.fillStyle = "#000000"
        ctx.font = "bold 16px sans-serif"
        ctx.textAlign = "center"
        ctx.textBaseline = "middle"
        ctx.fillText(selectedYear.toString(), centerX, centerY - 20)

        ctx.font = "14px sans-serif"
        ctx.fillStyle = "#3b82f6"
        ctx.fillText(`Conservative Party: ${selectedData.conservative}%`, centerX, centerY + 5)
        ctx.fillStyle = "#ef4444"
        ctx.fillText(`Labour Party: ${selectedData.labour}%`, centerX, centerY + 25)
        ctx.fillStyle = "#0078D7"
        ctx.fillText(`Reform UK: ${selectedData.reform}%`, centerX, centerY + 45)

        // Add note for election years
        if ([2015, 2017, 2019, 2024].includes(selectedYear)) {
          ctx.fillStyle = "#000000"
          ctx.font = "italic 12px sans-serif"
          ctx.fillText("General Election", centerX, centerY + 65)
        } else if (selectedYear === 2025) {
          ctx.fillStyle = "#000000"
          ctx.font = "italic 12px sans-serif"
          ctx.fillText("Projection", centerX, centerY + 65)
        }
      }
    } else {
      ctx.fillStyle = "#6b7280"
      ctx.font = "14px sans-serif"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText("Select a year", centerX, centerY)
    }

    // Draw legend
    const legendX = 20
    const legendY = 20
    const legendItems = [
      { label: "Conservative Party", color: "#3b82f6" },
      { label: "Labour Party", color: "#ef4444" },
      { label: "Reform UK", color: "#0078D7" },
    ]

    legendItems.forEach((item, i) => {
      const y = legendY + i * 20

      // Draw color box
      ctx.fillStyle = item.color
      ctx.fillRect(legendX, y, 15, 15)

      // Draw label
      ctx.fillStyle = "#000000"
      ctx.font = "12px sans-serif"
      ctx.textAlign = "left"
      ctx.textBaseline = "middle"
      ctx.fillText(item.label, legendX + 25, y + 7)
    })
  }

  // Handle mouse move for hover effects
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current
    if (!canvas) return

    const rect = canvas.getBoundingClientRect()
    const x = (e.clientX - rect.left) * (canvas.width / rect.width / 2)
    const y = (e.clientY - rect.top) * (canvas.height / rect.height / 2)

    // Calculate center and mouse position relative to center
    const centerX = canvas.width / 4 // Divide by 4 because of the 2x scaling
    const centerY = canvas.height / 4
    const dx = x - centerX
    const dy = y - centerY

    // Calculate angle and distance from center
    const angle = Math.atan2(dy, dx)
    const distance = Math.sqrt(dx * dx + dy * dy)

    // Normalize angle to 0-2π range
    const normalizedAngle = angle < 0 ? angle + Math.PI * 2 : angle

    // Check if mouse is within the chart area
    const maxRadius = Math.min(centerX, centerY) * 0.8
    if (distance <= maxRadius && distance >= maxRadius * 0.3) {
      // Find which year segment the angle corresponds to
      const yearCount = votingTrends.length
      const segmentAngle = (Math.PI * 2) / yearCount

      for (let i = 0; i < yearCount; i++) {
        const startAngle = i * segmentAngle - Math.PI / 2 // Start from top
        const endAngle = startAngle + segmentAngle

        // Check if angle is within this segment
        if (normalizedAngle >= startAngle && normalizedAngle < endAngle) {
          setSelectedYear(votingTrends[i].year)
          setTooltipPosition({ x: e.clientX, y: e.clientY })
          break
        }
      }
    } else if (selectedYear !== null) {
      setSelectedYear(null)
    }
  }

  // Handle click on segments
  const handleClick = () => {
    if (selectedYear !== null) {
      const data = votingTrends.find((d) => d.year === selectedYear)
      if (data) {
        let description = `Conservative Party: ${data.conservative}%, Labour Party: ${data.labour}%, Reform UK: ${data.reform}%`

        // Add note for election years
        if ([2015, 2017, 2019, 2024].includes(data.year)) {
          description += " (General Election)"
        } else if (data.year === 2025) {
          description += " (Projection)"
        }

        toast({
          title: `${data.year} Voting Data`,
          description: description,
        })
      }
    }
  }

  // Draw chart on component mount and when selection changes
  useEffect(() => {
    drawCircularPlot()

    const handleResize = () => {
      drawCircularPlot()
    }

    window.addEventListener("resize", handleResize)
    return () => {
      window.removeEventListener("resize", handleResize)
    }
  }, [selectedYear])

  return (
    <div className="relative w-full h-full flex items-center justify-center">
      <canvas ref={canvasRef} className="cursor-pointer" onMouseMove={handleMouseMove} onClick={handleClick} />
    </div>
  )
}

